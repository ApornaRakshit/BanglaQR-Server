import { db } from "../../../config/db.js";

export const adminInstitutionsRepository = {
  /**
   * Summary KPI Statistics from real database counts
   */
  async getStats() {
    const [instRows] = await db.query(`
      SELECT
        COUNT(*) AS total_institutions,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_institutions,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_institutions,
        SUM(CASE WHEN status IN ('inactive', 'suspended') THEN 1 ELSE 0 END) AS inactive_institutions
      FROM institutions
    `);

    const [userRows] = await db.query(`
      SELECT COUNT(DISTINCT user_id) AS total_users
      FROM institution_users
      WHERE membership_status = 'active'
    `);

    const [appRows] = await db.query(`
      SELECT COUNT(*) AS total_applications
      FROM merchant_gateway_applications
      WHERE institution_id IS NOT NULL
    `);

    const totalInstitutions = Number(instRows[0]?.total_institutions || 0);
    const activeInstitutions = Number(instRows[0]?.active_institutions || 0);
    const draftInstitutions = Number(instRows[0]?.draft_institutions || 0);
    const inactiveInstitutions = Number(instRows[0]?.inactive_institutions || 0);
    const totalUsers = Number(userRows[0]?.total_users || 0);
    const totalApplications = Number(appRows[0]?.total_applications || 0);

    return {
      totalInstitutions,
      activeInstitutions,
      draftInstitutions,
      inactiveInstitutions,
      totalUsers,
      totalApplications,
    };
  },

  /**
   * List Institutions with search, filters, pagination and real linked staff & service counts
   */
  async list({ search = "", type = "all", status = "all", page = 1, limit = 15 }) {
    const conditions = [];
    const params = [];

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(i.name LIKE ? OR i.institution_code LIKE ? OR i.support_email LIKE ?)");
      params.push(term, term, term);
    }

    if (type && type !== "all") {
      conditions.push("i.institution_type = ?");
      params.push(type);
    }

    if (status && status !== "all") {
      conditions.push("i.status = ?");
      params.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `SELECT COUNT(*) AS total FROM institutions i ${where}`,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        i.*,
        i.institution_code AS code,
        COUNT(DISTINCT iu.id) AS staff_count,
        COUNT(DISTINCT g.id) AS service_count,
        COUNT(DISTINCT mga.id) AS linked_application_count,
        COUNT(DISTINCT b.id) AS branches_count
      FROM institutions i
      LEFT JOIN institution_users iu ON iu.institution_id = i.id AND iu.membership_status = 'active'
      LEFT JOIN gateways g ON g.institution_id = i.id
      LEFT JOIN merchant_gateway_applications mga ON mga.institution_id = i.id
      LEFT JOIN institution_branches b ON b.institution_id = i.id
      ${where}
      GROUP BY i.id
      ORDER BY i.created_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    for (const row of rows) {
      const [svcRows] = await db.query(
        `SELECT id, name, code, service_type, status FROM gateways WHERE institution_id = ? LIMIT 3`,
        [row.id]
      );
      row.services = svcRows;
    }

    return {
      institutions: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  /**
   * Find single institution by ID with full details
   */
  async getById(id) {
    const validId = Number(id);
    if (!validId || isNaN(validId)) return null;

    const [rows] = await db.query(
      `
      SELECT
        i.*,
        COUNT(DISTINCT iu.id) AS staff_count,
        COUNT(DISTINCT g.id) AS service_count,
        COUNT(DISTINCT mga.id) AS linked_application_count,
        COUNT(DISTINCT b.id) AS branches_count
      FROM institutions i
      LEFT JOIN institution_users iu ON iu.institution_id = i.id AND iu.membership_status = 'active'
      LEFT JOIN gateways g ON g.institution_id = i.id
      LEFT JOIN merchant_gateway_applications mga ON mga.institution_id = i.id
      LEFT JOIN institution_branches b ON b.institution_id = i.id
      WHERE i.id = ?
      GROUP BY i.id
      LIMIT 1
      `,
      [validId]
    );

    return rows[0] || null;
  },

  /**
   * Find institution by code for unique check
   */
  async getByCode(code) {
    const [rows] = await db.query(`SELECT * FROM institutions WHERE institution_code = ? LIMIT 1`, [code]);
    return rows[0] || null;
  },

  /**
   * Create new institution
   */
  async create({
    institutionCode,
    name,
    institutionType = "bank",
    logoUrl = null,
    description = null,
    websiteUrl = null,
    supportEmail = null,
    supportPhone = null,
    headOfficeAddress = null,
    division = null,
    district = null,
    upazila = null,
    servicesOffered = null,
    status = "draft",
  }) {
    const [res] = await db.execute(
      `
      INSERT INTO institutions
        (institution_code, name, institution_type, logo_url, description, website_url, support_email, support_phone, head_office_address, division, district, upazila, services_offered, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        institutionCode,
        name,
        institutionType,
        logoUrl,
        description,
        websiteUrl,
        supportEmail,
        supportPhone,
        headOfficeAddress,
        division,
        district,
        upazila,
        servicesOffered,
        status,
      ]
    );

    return res.insertId;
  },

  /**
   * Update institution details
   */
  async update(id, data) {
    const updates = [];
    const params = [];

    const allowedFields = [
      "institution_code",
      "name",
      "institution_type",
      "logo_url",
      "description",
      "website_url",
      "support_email",
      "support_phone",
      "head_office_address",
      "division",
      "district",
      "upazila",
      "services_offered",
      "status",
    ];

    const mapped = {
      institution_code: data.institutionCode || data.code,
      name: data.name,
      institution_type: data.institutionType || data.type,
      logo_url: data.logoUrl,
      description: data.description,
      website_url: data.websiteUrl,
      support_email: data.supportEmail || data.contactEmail,
      support_phone: data.supportPhone || data.contactPhone,
      head_office_address: data.headOfficeAddress,
      division: data.division,
      district: data.district,
      upazila: data.upazila,
      services_offered: data.servicesOffered,
      status: data.status,
    };

    for (const [col, val] of Object.entries(mapped)) {
      if (val !== undefined && allowedFields.includes(col)) {
        updates.push(`\`${col}\` = ?`);
        params.push(val);
      }
    }

    if (!updates.length) return false;

    updates.push("updated_at = NOW()");
    params.push(id);

    await db.execute(`UPDATE institutions SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  /**
   * Check dependent records before safe delete
   */
  async getDependencies(id) {
    const [users] = await db.query(`SELECT COUNT(*) AS c FROM institution_users WHERE institution_id = ?`, [id]);
    const [services] = await db.query(`SELECT COUNT(*) AS c FROM gateways WHERE institution_id = ?`, [id]);
    const [applications] = await db.query(
      `SELECT COUNT(*) AS c FROM merchant_gateway_applications WHERE institution_id = ?`,
      [id]
    );
    const [branches] = await db.query(
      `SELECT COUNT(*) AS c FROM institution_branches WHERE institution_id = ?`,
      [id]
    );

    return {
      usersCount: Number(users[0]?.c || 0),
      servicesCount: Number(services[0]?.c || 0),
      applicationsCount: Number(applications[0]?.c || 0),
      branchesCount: Number(branches[0]?.c || 0),
    };
  },

  /**
   * Delete institution permanently if safe
   */
  async delete(id) {
    await db.execute(`DELETE FROM institutions WHERE id = ?`, [id]);
    return true;
  },

  /* ========================================================================
     INSTITUTION SERVICES MANAGEMENT
     ======================================================================== */

  async listServices({ institutionId = null, status = "all", search = "", page = 1, limit = 20 }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("g.institution_id = ?");
      params.push(validInstId);
    }

    if (status && status !== "all") {
      conditions.push("g.status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(g.name LIKE ? OR g.code LIKE ? OR i.name LIKE ?)");
      params.push(term, term, term);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM gateways g
      LEFT JOIN institutions i ON i.id = g.institution_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        g.*,
        i.name AS institution_name,
        i.institution_code,
        i.institution_type
      FROM gateways g
      LEFT JOIN institutions i ON i.id = g.institution_id
      ${where}
      ORDER BY g.display_order ASC, g.id DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      services: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async associateService(gatewayId, institutionId) {
    const validInstId = Number(institutionId);
    await db.execute(
      `UPDATE gateways SET institution_id = ?, updated_at = NOW() WHERE id = ?`,
      [validInstId, gatewayId]
    );
    return true;
  },

  async disassociateService(gatewayId) {
    await db.execute(
      `UPDATE gateways SET institution_id = NULL, updated_at = NOW() WHERE id = ?`,
      [gatewayId]
    );
    return true;
  },

  /* ========================================================================
     INSTITUTION USERS / STAFF MANAGEMENT
     ======================================================================== */

  async listStaff({ institutionId = null, status = "all", search = "", page = 1, limit = 20 }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("iu.institution_id = ?");
      params.push(validInstId);
    }

    if (status && status !== "all") {
      conditions.push("iu.membership_status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(iu.staff_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR i.name LIKE ? OR r.name LIKE ?)");
      params.push(term, term, term, term, term);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        iu.id AS id,
        iu.id AS membership_id,
        iu.membership_status,
        iu.membership_status AS status,
        iu.created_at AS joined_at,
        u.id AS user_id,
        COALESCE(
          NULLIF(iu.staff_name, ''),
          NULLIF(u.email, ''),
          CONCAT('User #', u.id)
        ) AS name,
        COALESCE(NULLIF(iu.staff_name, ''), NULLIF(u.email, '')) AS full_name,
        iu.staff_name,
        u.email,
        u.phone,
        u.status AS user_status,
        u.last_login_at AS last_login_at,
        r.id AS role_id,
        r.name AS role_name,
        r.name AS institution_role,
        r.description AS role_description,
        i.id AS institution_id,
        i.name AS institution_name,
        i.institution_code,
        i.institution_code AS code,
        i.institution_type
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      ${where}
      ORDER BY iu.id DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      staff: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getStaffMembership(membershipId) {
    return this.getStaffById(membershipId);
  },

  async getStaffById(membershipId) {
    const id = Number(membershipId);
    if (!Number.isSafeInteger(id) || id <= 0) {
      const err = new Error("Invalid staff membership ID");
      err.statusCode = 400;
      throw err;
    }

    const [rows] = await db.query(
      `
      SELECT
        iu.id AS id,
        iu.id AS membership_id,
        iu.membership_status,
        iu.membership_status AS status,
        iu.created_at AS joined_at,
        u.id AS user_id,
        COALESCE(
          NULLIF(iu.staff_name, ''),
          NULLIF(u.email, ''),
          CONCAT('User #', u.id)
        ) AS name,
        COALESCE(NULLIF(iu.staff_name, ''), NULLIF(u.email, '')) AS full_name,
        iu.staff_name,
        u.email,
        u.phone,
        u.status AS user_status,
        u.last_login_at AS last_login_at,
        r.id AS role_id,
        r.name AS role_name,
        r.name AS institution_role,
        r.description AS role_description,
        i.id AS institution_id,
        i.name AS institution_name,
        i.institution_code,
        i.institution_code AS code,
        i.institution_type
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      WHERE iu.id = ?
      LIMIT 1
      `,
      [id]
    );
    return rows[0] || null;
  },

  async createStaffMembership({ userId, institutionId, roleId, staffName = null, membershipStatus = "active" }) {
    const [res] = await db.execute(
      `
      INSERT INTO institution_users (user_id, institution_id, role_id, staff_name, membership_status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [userId, institutionId, roleId, staffName, membershipStatus]
    );
    return res.insertId;
  },

  async updateStaffMembership(membershipId, { roleId = null, membershipStatus = null }) {
    const updates = [];
    const params = [];

    if (roleId) {
      updates.push("role_id = ?");
      params.push(roleId);
    }
    if (membershipStatus) {
      updates.push("membership_status = ?");
      params.push(membershipStatus);
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(membershipId);

    await db.execute(`UPDATE institution_users SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  /* ========================================================================
     BRANCHES & LOCATIONS MANAGEMENT
     ======================================================================== */

  async getBranchStats(institutionId) {
    const validInstId = Number(institutionId);
    const [rows] = await db.query(
      `
      SELECT
        COUNT(*) AS total_branches,
        COUNT(DISTINCT division) AS divisions_count,
        COUNT(DISTINCT district) AS districts_count,
        COALESCE(SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END), 0) AS active_branches,
        COALESCE(SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END), 0) AS inactive_branches,
        COALESCE(SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END), 0) AS suspended_branches,
        COALESCE(SUM(CASE WHEN is_demo = 1 THEN 1 ELSE 0 END), 0) AS demo_branches
      FROM institution_branches
      WHERE institution_id = ? AND is_archived = 0
      `,
      [validInstId]
    );

    const r = rows[0] || {};
    return {
      totalBranches: Number(r.total_branches || 0),
      divisionsCount: Number(r.divisions_count || 0),
      districtsCount: Number(r.districts_count || 0),
      activeBranches: Number(r.active_branches || 0),
      inactiveBranches: Number(r.inactive_branches || 0),
      suspendedBranches: Number(r.suspended_branches || 0),
      demoBranches: Number(r.demo_branches || 0),
    };
  },

  async listBranches(
    institutionId,
    {
      division = "all",
      district = "all",
      upazila = "all",
      status = "all",
      demoFilter = "all",
      includeArchived = false,
      search = "",
      page = 1,
      limit = 15,
    }
  ) {
    const validInstId = Number(institutionId);
    const conditions = ["b.institution_id = ?"];
    const params = [validInstId];

    if (!includeArchived) {
      conditions.push("b.is_archived = 0");
    }

    if (demoFilter === "demo") {
      conditions.push("b.is_demo = 1");
    } else if (demoFilter === "real") {
      conditions.push("b.is_demo = 0");
    }

    if (division && division !== "all") {
      conditions.push("(LOWER(b.division) = LOWER(?) OR b.division_id = ?)");
      params.push(division, isNaN(Number(division)) ? 0 : Number(division));
    }
    if (district && district !== "all") {
      conditions.push("(LOWER(b.district) = LOWER(?) OR b.district_id = ?)");
      params.push(district, isNaN(Number(district)) ? 0 : Number(district));
    }
    if (upazila && upazila !== "all") {
      conditions.push("(LOWER(b.upazila) = LOWER(?) OR b.upazila_id = ?)");
      params.push(upazila, isNaN(Number(upazila)) ? 0 : Number(upazila));
    }
    if (status && status !== "all") {
      conditions.push("b.status = ?");
      params.push(status);
    }
    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push(
        "(b.branch_name LIKE ? OR b.branch_code LIKE ? OR b.routing_number LIKE ? OR b.address LIKE ? OR b.phone LIKE ? OR b.manager_name LIKE ?)"
      );
      params.push(term, term, term, term, term, term);
    }

    const where = `WHERE ${conditions.join(" AND ")}`;
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `SELECT COUNT(*) AS total FROM institution_branches b ${where}`,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT b.*, i.name AS institution_name, i.institution_code
      FROM institution_branches b
      JOIN institutions i ON i.id = b.institution_id
      ${where}
      ORDER BY b.is_demo ASC, b.created_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      branches: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getBranchById(branchId) {
    const [rows] = await db.query(
      `
      SELECT b.*, i.name AS institution_name, i.institution_code, i.logo_url AS institution_logo
      FROM institution_branches b
      JOIN institutions i ON i.id = b.institution_id
      WHERE b.id = ?
      LIMIT 1
      `,
      [branchId]
    );
    return rows[0] || null;
  },

  async getBranchByCode(institutionId, branchCode) {
    const [rows] = await db.query(
      `SELECT * FROM institution_branches WHERE institution_id = ? AND branch_code = ? LIMIT 1`,
      [institutionId, branchCode]
    );
    return rows[0] || null;
  },

  async createBranch(data) {
    const [res] = await db.execute(
      `
      INSERT INTO institution_branches
        (institution_id, branch_name, branch_code, routing_number, division, district, upazila, division_id, district_id, upazila_id, post_office, postal_code, address, phone, email, manager_name, notes, status, is_demo, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        data.institutionId,
        data.branchName,
        data.branchCode,
        data.routingNumber || null,
        data.division,
        data.district,
        data.upazila,
        data.divisionId || null,
        data.districtId || null,
        data.upazilaId || null,
        data.postOffice || null,
        data.postalCode || null,
        data.address || null,
        data.phone || null,
        data.email || null,
        data.managerName || null,
        data.notes || null,
        data.status || "active",
        data.isDemo ? 1 : 0,
      ]
    );
    return res.insertId;
  },

  async updateBranch(branchId, data) {
    const updates = [];
    const params = [];

    const fieldMap = {
      branchName: "branch_name",
      branchCode: "branch_code",
      routingNumber: "routing_number",
      division: "division",
      district: "district",
      upazila: "upazila",
      divisionId: "division_id",
      districtId: "district_id",
      upazilaId: "upazila_id",
      postOffice: "post_office",
      postalCode: "postal_code",
      address: "address",
      phone: "phone",
      email: "email",
      managerName: "manager_name",
      notes: "notes",
      status: "status",
      isDemo: "is_demo",
      isArchived: "is_archived",
    };

    for (const [key, col] of Object.entries(fieldMap)) {
      if (data[key] !== undefined) {
        updates.push(`\`${col}\` = ?`);
        params.push(data[key]);
      }
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(branchId);

    await db.execute(`UPDATE institution_branches SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  async updateBranchStatus(branchId, status) {
    await db.execute(`UPDATE institution_branches SET status = ?, updated_at = NOW() WHERE id = ?`, [status, branchId]);
    return true;
  },

  async archiveBranch(branchId, archivedBy = "Admin") {
    await db.execute(
      `UPDATE institution_branches SET is_archived = 1, status = 'inactive', archived_at = NOW(), archived_by = ?, updated_at = NOW() WHERE id = ?`,
      [archivedBy, branchId]
    );
    return true;
  },

  async toggleDemoBranch(branchId, isDemo) {
    await db.execute(
      `UPDATE institution_branches SET is_demo = ?, updated_at = NOW() WHERE id = ?`,
      [isDemo ? 1 : 0, branchId]
    );
    return true;
  },

  async deleteBranch(branchId) {
    const [appCheck] = await db.query(
      `SELECT COUNT(*) AS c FROM merchant_gateway_applications WHERE branch_id = ?`,
      [branchId]
    );
    if (appCheck[0]?.c > 0) {
      const err = new Error(
        `Cannot delete branch referenced by ${appCheck[0].c} merchant application(s). Mark it as Inactive or Suspended instead.`
      );
      err.statusCode = 409;
      throw err;
    }

    const [kycCheck] = await db.query(
      `SELECT COUNT(*) AS c FROM merchant_kyc WHERE branch_id = ?`,
      [branchId]
    );
    if (kycCheck[0]?.c > 0) {
      const err = new Error(
        `Cannot delete branch referenced by ${kycCheck[0].c} merchant KYC profile(s). Mark it as Inactive or Suspended instead.`
      );
      err.statusCode = 409;
      throw err;
    }

    await db.execute(`DELETE FROM institution_branches WHERE id = ?`, [branchId]);
    return true;
  },

  /* ========================================================================
     BANGLADESH GEOGRAPHIC MASTER DATA (bd_divisions, bd_districts, bd_upazilas)
     ======================================================================== */

  async getGeoDivisions() {
    const [rows] = await db.query(
      `SELECT id, division_name AS name, division_name_bn AS name_bn, division_code AS code 
       FROM bd_divisions 
       ORDER BY division_name ASC`
    );
    return rows;
  },

  async getGeoDistricts(divisionIdOrName = null) {
    let where = "";
    const params = [];

    if (divisionIdOrName) {
      if (!isNaN(Number(divisionIdOrName)) && Number(divisionIdOrName) > 0) {
        where = "WHERE d.division_id = ?";
        params.push(Number(divisionIdOrName));
      } else {
        where = "WHERE LOWER(gdiv.division_name) = LOWER(?) OR LOWER(COALESCE(gdiv.division_name_bn, '')) = LOWER(?)";
        params.push(String(divisionIdOrName).trim(), String(divisionIdOrName).trim());
      }
    }

    const [rows] = await db.query(
      `
      SELECT 
        d.id, 
        d.division_id, 
        d.district_name AS name, 
        d.district_name_bn AS name_bn, 
        d.district_code AS code, 
        gdiv.division_name AS division_name, 
        gdiv.division_name_bn AS division_name_bn
      FROM bd_districts d
      JOIN bd_divisions gdiv ON gdiv.id = d.division_id
      ${where}
      ORDER BY d.district_name ASC
      `,
      params
    );
    return rows;
  },

  async getGeoUpazilas(districtIdOrName = null) {
    let where = "";
    const params = [];

    if (districtIdOrName) {
      if (!isNaN(Number(districtIdOrName)) && Number(districtIdOrName) > 0) {
        where = "WHERE u.district_id = ?";
        params.push(Number(districtIdOrName));
      } else {
        where = "WHERE LOWER(gdist.district_name) = LOWER(?) OR LOWER(COALESCE(gdist.district_name_bn, '')) = LOWER(?)";
        params.push(String(districtIdOrName).trim(), String(districtIdOrName).trim());
      }
    }

    const [rows] = await db.query(
      `
      SELECT 
        u.id, 
        u.district_id, 
        u.upazila_name AS name, 
        u.upazila_name_bn AS name_bn, 
        u.location_type, 
        gdist.district_name AS district_name, 
        gdist.district_name_bn AS district_name_bn
      FROM bd_upazilas u
      JOIN bd_districts gdist ON gdist.id = u.district_id
      ${where}
      ORDER BY u.upazila_name ASC
      `,
      params
    );
    return rows;
  },

  async validateGeoHierarchy(divisionName, districtName, upazilaName) {
    if (!divisionName || !districtName || !upazilaName) {
      return { valid: false, message: "Division, district, and upazila/thana are required." };
    }

    const [rows] = await db.query(
      `
      SELECT u.id AS upazila_id, d.id AS district_id, gdiv.id AS division_id
      FROM bd_upazilas u
      JOIN bd_districts d ON d.id = u.district_id
      JOIN bd_divisions gdiv ON gdiv.id = d.division_id
      WHERE (LOWER(gdiv.division_name) = LOWER(?) OR LOWER(COALESCE(gdiv.division_name_bn, '')) = LOWER(?))
        AND (LOWER(d.district_name) = LOWER(?) OR LOWER(COALESCE(d.district_name_bn, '')) = LOWER(?))
        AND (LOWER(u.upazila_name) = LOWER(?) OR LOWER(COALESCE(u.upazila_name_bn, '')) = LOWER(?))
      LIMIT 1
      `,
      [
        divisionName.trim(), divisionName.trim(),
        districtName.trim(), districtName.trim(),
        upazilaName.trim(), upazilaName.trim(),
      ]
    );

    if (rows.length > 0) {
      return { valid: true, geoIds: rows[0] };
    }

    // Check if district belongs to division
    const [distCheck] = await db.query(
      `
      SELECT d.id
      FROM bd_districts d
      JOIN bd_divisions gdiv ON gdiv.id = d.division_id
      WHERE (LOWER(gdiv.division_name) = LOWER(?) OR LOWER(COALESCE(gdiv.division_name_bn, '')) = LOWER(?))
        AND (LOWER(d.district_name) = LOWER(?) OR LOWER(COALESCE(d.district_name_bn, '')) = LOWER(?))
      LIMIT 1
      `,
      [divisionName.trim(), divisionName.trim(), districtName.trim(), districtName.trim()]
    );

    if (distCheck.length === 0) {
      return { valid: false, message: `District "${districtName}" does not belong to Division "${divisionName}".` };
    }

    return { valid: false, message: `Upazila/Thana "${upazilaName}" was not found under District "${districtName}".` };
  },

  /* ========================================================================
     ACTIVE PUBLIC / MERCHANT INSTITUTION & BRANCH LOOKUPS
     ======================================================================== */

  async getActiveInstitutions() {
    const [rows] = await db.query(
      `
      SELECT 
        i.id, 
        i.name, 
        i.institution_code, 
        i.institution_type, 
        i.logo_url, 
        i.website_url, 
        i.support_phone, 
        i.support_email,
        COUNT(b.id) AS branches_count
      FROM institutions i
      LEFT JOIN institution_branches b ON b.institution_id = i.id AND b.status = 'active' AND b.is_archived = 0
      WHERE i.status = 'active'
      GROUP BY i.id
      ORDER BY i.name ASC
      `
    );
    return rows;
  },

  async getActiveBranchesForInstitution(institutionId) {
    const validInstId = Number(institutionId);
    const [rows] = await db.query(
      `
      SELECT 
        b.id, 
        b.institution_id, 
        b.branch_name, 
        b.branch_code, 
        b.routing_number, 
        b.division, 
        b.district, 
        b.upazila, 
        b.post_office, 
        b.postal_code, 
        b.address, 
        b.phone, 
        b.email, 
        b.manager_name,
        b.is_demo
      FROM institution_branches b
      WHERE b.institution_id = ? AND b.status = 'active' AND b.is_archived = 0
      ORDER BY b.branch_name ASC
      `,
      [validInstId]
    );
    return rows;
  },

  /* ========================================================================
     INSTITUTION KYC REQUIREMENTS MANAGEMENT (EXPANDED DYNAMIC MODULE)
     ======================================================================== */

  async listKycRequirements({ institutionId = null, serviceId = null, category = "all", status = "all" }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("ikr.institution_id = ?");
      params.push(validInstId);
    }

    if (serviceId !== null && serviceId !== undefined && serviceId !== "all" && !isNaN(Number(serviceId)) && Number(serviceId) > 0) {
      conditions.push("(ikr.applicable_service_id = ? OR ikr.applicable_service_id IS NULL)");
      params.push(Number(serviceId));
    }

    if (category && category !== "all") {
      conditions.push("ikr.requirement_category = ?");
      params.push(category);
    }

    if (status && status !== "all") {
      conditions.push("ikr.status = ?");
      params.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const [rows] = await db.query(
      `
      SELECT
        ikr.*,
        i.name AS institution_name,
        i.institution_code,
        g.name AS service_name,
        g.service_type
      FROM institution_kyc_requirements ikr
      JOIN institutions i ON i.id = ikr.institution_id
      LEFT JOIN gateways g ON g.id = ikr.applicable_service_id
      ${where}
      ORDER BY ikr.display_order ASC, ikr.id ASC
      `,
      params
    );

    return rows;
  },

  async getKycRequirementById(id) {
    const [rows] = await db.query(
      `
      SELECT
        ikr.*,
        i.name AS institution_name,
        i.institution_code,
        g.name AS service_name,
        g.service_type
      FROM institution_kyc_requirements ikr
      JOIN institutions i ON i.id = ikr.institution_id
      LEFT JOIN gateways g ON g.id = ikr.applicable_service_id
      WHERE ikr.id = ?
      LIMIT 1
      `,
      [Number(id)]
    );

    return rows[0] || null;
  },

  async getRelatedKycRequirements({ institutionId, serviceId = null, excludeId = null }) {
    if (!institutionId || isNaN(Number(institutionId))) return [];
    const conditions = ["ikr.institution_id = ?"];
    const params = [Number(institutionId)];

    if (excludeId && !isNaN(Number(excludeId))) {
      conditions.push("ikr.id != ?");
      params.push(Number(excludeId));
    }

    if (serviceId && !isNaN(Number(serviceId)) && Number(serviceId) > 0) {
      conditions.push("(ikr.applicable_service_id = ? OR ikr.applicable_service_id IS NULL)");
      params.push(Number(serviceId));
    }

    const [rows] = await db.query(
      `
      SELECT
        ikr.id,
        ikr.institution_id,
        ikr.applicable_service_id,
        ikr.name,
        ikr.requirement_code,
        ikr.requirement_category,
        ikr.document_type,
        ikr.is_mandatory,
        ikr.status,
        ikr.display_order,
        g.name AS service_name
      FROM institution_kyc_requirements ikr
      LEFT JOIN gateways g ON g.id = ikr.applicable_service_id
      WHERE ${conditions.join(" AND ")}
      ORDER BY ikr.display_order ASC, ikr.id ASC
      LIMIT 10
      `,
      params
    );

    return rows;
  },

  async createKycRequirement({
    institutionId,
    applicableServiceId = null,
    name,
    requirementCode,
    requirementCategory = "business_identity",
    requirementType = "document_upload",
    applicableBusinessTypes = null,
    documentType = "other",
    description = null,
    instructions = null,
    allowedExtensions = "pdf,jpg,jpeg,png,webp",
    maxFileSizeMb = 5,
    maxPdfPages = 5,
    maxFilesCount = 1,
    documentSides = "single",
    isMandatory = true,
    requiresApproval = true,
    reviewInstructions = null,
    adminNotes = null,
    autoVerifyOcr = false,
    checkExpiry = false,
    requireMatchingName = false,
    expiryFieldName = "expiry_date",
    minValidityDays = 30,
    referenceApiUrl = null,
    sampleDocumentUrl = null,
    sampleDocumentUrls = null,
    status = "active",
    displayOrder = 0,
  }) {
    const businessTypesStr = Array.isArray(applicableBusinessTypes)
      ? JSON.stringify(applicableBusinessTypes)
      : applicableBusinessTypes;

    const sampleUrlsStr = Array.isArray(sampleDocumentUrls)
      ? JSON.stringify(sampleDocumentUrls)
      : (typeof sampleDocumentUrls === "object" && sampleDocumentUrls !== null)
      ? JSON.stringify(sampleDocumentUrls)
      : sampleDocumentUrls;

    const [res] = await db.execute(
      `
      INSERT INTO institution_kyc_requirements
        (institution_id, applicable_service_id, name, requirement_code, requirement_category, requirement_type,
         applicable_business_types, document_type, description, instructions, allowed_extensions, max_file_size_mb,
         max_pdf_pages, max_files_count, document_sides, is_mandatory, requires_approval, review_instructions,
         admin_notes, auto_verify_ocr, check_expiry, require_matching_name, expiry_field_name, min_validity_days,
         reference_api_url, sample_document_url, sample_document_urls, status, display_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        institutionId,
        applicableServiceId ? Number(applicableServiceId) : null,
        name,
        requirementCode,
        requirementCategory,
        requirementType,
        businessTypesStr,
        documentType || "other",
        description,
        instructions,
        allowedExtensions,
        Number(maxFileSizeMb) || 5,
        Number(maxPdfPages) || 5,
        Number(maxFilesCount) || 1,
        documentSides,
        isMandatory ? 1 : 0,
        requiresApproval ? 1 : 0,
        reviewInstructions || adminNotes,
        adminNotes || reviewInstructions,
        autoVerifyOcr ? 1 : 0,
        checkExpiry ? 1 : 0,
        requireMatchingName ? 1 : 0,
        expiryFieldName || "expiry_date",
        Number(minValidityDays) || 30,
        referenceApiUrl || null,
        sampleDocumentUrl || null,
        sampleUrlsStr || null,
        status,
        Number(displayOrder) || 0,
      ]
    );

    return res.insertId;
  },

  async updateKycRequirement(id, data) {
    const updates = [];
    const params = [];

    const fieldMap = {
      institutionId: "institution_id",
      applicableServiceId: "applicable_service_id",
      name: "name",
      requirementCode: "requirement_code",
      requirementCategory: "requirement_category",
      requirementType: "requirement_type",
      applicableBusinessTypes: "applicable_business_types",
      documentType: "document_type",
      description: "description",
      instructions: "instructions",
      allowedExtensions: "allowed_extensions",
      maxFileSizeMb: "max_file_size_mb",
      maxPdfPages: "max_pdf_pages",
      maxFilesCount: "max_files_count",
      documentSides: "document_sides",
      isMandatory: "is_mandatory",
      requiresApproval: "requires_approval",
      reviewInstructions: "review_instructions",
      adminNotes: "admin_notes",
      autoVerifyOcr: "auto_verify_ocr",
      checkExpiry: "check_expiry",
      requireMatchingName: "require_matching_name",
      expiryFieldName: "expiry_field_name",
      minValidityDays: "min_validity_days",
      referenceApiUrl: "reference_api_url",
      sampleDocumentUrl: "sample_document_url",
      sampleDocumentUrls: "sample_document_urls",
      status: "status",
      displayOrder: "display_order",
    };

    for (const [key, col] of Object.entries(fieldMap)) {
      if (data[key] !== undefined) {
        let val = data[key];
        if (key === "applicableBusinessTypes" && Array.isArray(val)) {
          val = JSON.stringify(val);
        } else if (key === "sampleDocumentUrls" && (Array.isArray(val) || (typeof val === "object" && val !== null))) {
          val = JSON.stringify(val);
        } else if (key === "isMandatory" || key === "requiresApproval" || key === "autoVerifyOcr" || key === "checkExpiry" || key === "requireMatchingName") {
          val = val ? 1 : 0;
        } else if (key === "applicableServiceId") {
          val = val ? Number(val) : null;
        }
        updates.push(`\`${col}\` = ?`);
        params.push(val);
      }
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(Number(id));

    await db.execute(`UPDATE institution_kyc_requirements SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  async deleteKycRequirement(id) {
    await db.execute(`DELETE FROM institution_kyc_requirements WHERE id = ?`, [id]);
    return true;
  },

  /* ========================================================================
     INSTITUTION MERCHANT APPLICATIONS
     ======================================================================== */

  async listInstitutionApplications(institutionId, { status = "all", search = "", page = 1, limit = 15 }) {
    const validInstId = Number(institutionId);
    const conditions = ["mga.institution_id = ?"];
    const params = [validInstId];

    if (status && status !== "all") {
      conditions.push("mga.status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(m.business_name LIKE ? OR m.trade_license_number LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR g.name LIKE ?)");
      params.push(term, term, term, term, term);
    }

    const where = `WHERE ${conditions.join(" AND ")}`;
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM merchant_gateway_applications mga
      JOIN merchants m ON m.id = mga.merchant_id
      JOIN users u ON u.id = m.user_id
      LEFT JOIN gateways g ON g.id = mga.gateway_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        mga.id AS application_id,
        mga.status AS application_status,
        mga.applied_at,
        mga.reviewed_at,
        mga.review_note,
        m.id AS merchant_id,
        m.business_name,
        m.trade_license_number,
        u.email AS merchant_email,
        u.phone AS merchant_phone,
        g.id AS gateway_id,
        g.name AS gateway_name,
        g.code AS gateway_code,
        b.id AS branch_id,
        b.branch_name,
        b.branch_code
      FROM merchant_gateway_applications mga
      JOIN merchants m ON m.id = mga.merchant_id
      JOIN users u ON u.id = m.user_id
      LEFT JOIN gateways g ON g.id = mga.gateway_id
      LEFT JOIN institution_branches b ON b.id = mga.branch_id
      ${where}
      ORDER BY mga.applied_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      applications: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getInstitutionApplicationStats(institutionId) {
    const validInstId = Number(institutionId);
    const [rows] = await db.query(
      `
      SELECT
        COUNT(*) AS total_applications,
        COALESCE(SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END), 0) AS pending_applications,
        COALESCE(SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END), 0) AS under_review_applications,
        COALESCE(SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END), 0) AS approved_applications,
        COALESCE(SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END), 0) AS rejected_applications,
        COALESCE(SUM(CASE WHEN status = 'additional_information_required' THEN 1 ELSE 0 END), 0) AS info_required_applications
      FROM merchant_gateway_applications
      WHERE institution_id = ?
      `,
      [validInstId]
    );

    const r = rows[0] || {};
    return {
      totalApplications: Number(r.total_applications || 0),
      pendingApplications: Number(r.pending_applications || 0),
      underReviewApplications: Number(r.under_review_applications || 0),
      approvedApplications: Number(r.approved_applications || 0),
      rejectedApplications: Number(r.rejected_applications || 0),
      infoRequiredApplications: Number(r.info_required_applications || 0),
    };
  },

  /* ========================================================================
     INSTITUTION SETTINGS MANAGEMENT
     ======================================================================== */

  async getSettings(institutionId) {
    const validInstId = Number(institutionId);
    if (!validInstId || isNaN(validInstId)) return {};

    const [rows] = await db.query(
      `SELECT * FROM institution_settings WHERE institution_id = ?`,
      [validInstId]
    );

    const result = {};
    for (const row of rows) {
      let val = row.setting_value;
      if (typeof val === "string") {
        try {
          val = JSON.parse(val);
        } catch (_) {}
      }
      result[row.setting_key] = val;
    }
    return result;
  },

  async saveSetting(institutionId, settingKey, settingValue, updatedBy = "Admin") {
    const validInstId = Number(institutionId);
    if (!validInstId || isNaN(validInstId)) return false;

    let jsonStr;
    try {
      jsonStr = JSON.stringify(settingValue);
    } catch (_) {
      jsonStr = JSON.stringify(String(settingValue));
    }

    await db.execute(
      `
      INSERT INTO institution_settings (institution_id, setting_key, setting_value, updated_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        setting_value = VALUES(setting_value),
        updated_by = VALUES(updated_by),
        updated_at = NOW()
      `,
      [validInstId, settingKey, jsonStr, updatedBy]
    );

    return true;
  },
};
