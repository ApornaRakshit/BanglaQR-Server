import { Router } from "express";
import { requireAuth } from "../../middlewares/auth.js";
import {
  requireInstitutionStaff,
  requireInstitutionScope,
} from "../../middlewares/permission.js";
import { institutionController } from "./institution.controller.js";

const router = Router();

// All routes require authentication and institution staff/admin membership
router.use(requireAuth);
router.use(requireInstitutionStaff);
router.use(requireInstitutionScope);

// Profile & Dashboard
router.get("/me", institutionController.getMe);
router.get("/dashboard", institutionController.getDashboard);

// Merchant Applications & KYC Correction Workflow
router.get("/applications", institutionController.listApplications);
router.get("/applications/:id", institutionController.getApplication);
router.post("/applications/:id/correction", institutionController.requestCorrection);
router.patch("/applications/corrections/:issueId/resolve", institutionController.resolveCorrection);
router.post("/applications/:id/review", institutionController.reviewApplication);

// Branches & Official Update Requests
router.get("/branches", institutionController.listBranches);
router.post("/branches/change-request", institutionController.requestBranchCorrection);

// Staff & Branch Scope Assignments
router.get("/staff", institutionController.listStaff);
router.post("/staff/:membershipId/branches", institutionController.assignStaffBranches);

// Services & Integrations
router.get("/services", institutionController.listServices);
router.post("/services", institutionController.saveService);

// Connections & Testing
router.get("/connections", institutionController.listConnections);
router.post("/connections/:serviceId/test", institutionController.testConnection);

// Reports
router.get("/reports", institutionController.getReports);

export default router;

