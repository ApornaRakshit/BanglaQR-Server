import { db } from "../config/db.js";

export function requirePermission(permissionName) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Authentication required",
      });
    }

    // Super admin bypasses specific permission checks
    if (req.user.role === "super_admin") {
      return next();
    }

    const permissions = req.user.permissions || [];
    if (!permissions.includes(permissionName)) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: You do not have permission to perform this action",
      });
    }

    next();
  };
}

export function requireRole(allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Authentication required",
      });
    }

    const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: Insufficient role privileges",
      });
    }

    next();
  };
}

export const ADMIN_ROLES = ["super_admin", "admin", "reviewer", "support_agent"];

export function requireAdmin(req, res, next) {
  return requireRole(ADMIN_ROLES)(req, res, next);
}

export const INSTITUTION_ROLES = [
  "bank_admin",
  "bank_reviewer",
  "bank_operations",
  "super_admin",
  "admin",
];

export function requireInstitutionStaff(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ success: false, message: "Authentication required" });
  }

  // Super admin and admin can access with optional query or context
  if (["super_admin", "admin"].includes(req.user.role)) {
    return next();
  }

  const effectiveRole = req.user.institutionRole || req.user.role;
  if (!INSTITUTION_ROLES.includes(effectiveRole)) {
    return res.status(403).json({
      success: false,
      message: "Forbidden: You must be an authorized institution staff member",
    });
  }

  if (!req.user.institutionId) {
    return res.status(403).json({
      success: false,
      message: "Forbidden: No active institution membership assigned to your account",
    });
  }

  next();
}

/**
 * Enforce that bank staff (bank_admin, bank_reviewer, bank_operations)
 * can only access data belonging to their assigned institution.
 */
export async function requireInstitutionScope(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ success: false, message: "Authentication required" });
  }

  // Super admin and system admin have universal access across institutions
  if (["super_admin", "admin"].includes(req.user.role)) {
    return next();
  }

  const targetInstitutionId =
    req.params?.institutionId || req.body?.institutionId || req.query?.institutionId;

  const userInstId = req.user.institutionId;

  if (!userInstId) {
    return res.status(403).json({
      success: false,
      message: "Forbidden: No active institution membership found",
    });
  }

  if (targetInstitutionId && Number(userInstId) !== Number(targetInstitutionId)) {
    return res.status(403).json({
      success: false,
      message: "Forbidden: You are only authorized to access records for your assigned banking institution.",
    });
  }

  next();
}



