import jwt from "jsonwebtoken";
import { env, isDevVerificationBypass } from "../config/env.js";
import { db } from "../config/db.js";

export async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
    const token = req.signedCookies?.bq_access || bearerToken;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Authentication required",
      });
    }

    const payload = jwt.verify(token, env.jwt.accessSecret);

    const [rows] = await db.execute(
      `
        SELECT
          u.id,
          u.email,
          u.phone,
          u.status,
          u.email_verified_at,
          u.phone_verified_at,
          u.two_factor_enabled,
          r.name AS role,
          r.id AS role_id
        FROM users u
        LEFT JOIN user_roles ur
          ON ur.user_id = u.id
        LEFT JOIN roles r
          ON r.id = ur.role_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [payload.sub]
    );

    if (!rows.length) {
      return res.status(401).json({
        success: false,
        message: "User account not found",
      });
    }

    const user = rows[0];

    if (user.status === "suspended") {
      return res.status(403).json({
        success: false,
        message: "Account is suspended. Please contact support.",
      });
    }

    if (user.status !== "active" && !isDevVerificationBypass()) {
      return res.status(403).json({
        success: false,
        message: `Account is ${user.status}`,
      });
    }

    // Fetch user permissions
    const [permRows] = await db.execute(
      `
        SELECT DISTINCT p.name
        FROM permissions p
        JOIN role_permissions rp ON rp.permission_id = p.id
        JOIN user_roles ur ON ur.role_id = rp.role_id
        WHERE ur.user_id = ?
      `,
      [user.id]
    );

    user.permissions = permRows.map((p) => p.name);

    // Fetch active institution membership from DB
    const [instRows] = await db.execute(
      `
        SELECT
          iu.id AS membership_id,
          iu.institution_id,
          iu.role_id AS institution_role_id,
          iu.membership_status,
          i.name AS institution_name,
          i.institution_code,
          i.institution_type,
          i.logo_url,
          i.status AS institution_status,
          r.name AS institution_role
        FROM institution_users iu
        JOIN institutions i ON i.id = iu.institution_id
        LEFT JOIN roles r ON r.id = iu.role_id
        WHERE iu.user_id = ? AND iu.membership_status = 'active'
        LIMIT 1
      `,
      [user.id]
    );

    if (instRows.length > 0) {
      user.institution = {
        membershipId: instRows[0].membership_id,
        institutionId: instRows[0].institution_id,
        name: instRows[0].institution_name,
        code: instRows[0].institution_code,
        type: instRows[0].institution_type,
        logoUrl: instRows[0].logo_url,
        status: instRows[0].institution_status,
        role: instRows[0].institution_role,
      };
      user.institutionId = instRows[0].institution_id;
      user.institutionRole = instRows[0].institution_role;
    } else {
      user.institution = null;
      user.institutionId = null;
      user.institutionRole = null;
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Invalid or expired session",
    });
  }
}