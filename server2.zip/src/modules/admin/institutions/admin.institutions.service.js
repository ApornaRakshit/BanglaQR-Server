import argon2 from "argon2";
import path from "path";
import fs from "fs/promises";
import crypto from "crypto";
import { db } from "../../../config/db.js";
import { adminInstitutionsRepository } from "./admin.institutions.repository.js";
import { logAdminAudit } from "../../../utils/auditLogger.js";

const PUBLIC_UPLOADS_DIR = path.resolve(process.cwd(), "public/uploads/institutions");

async function ensureUploadDir() {
  try {
    await fs.mkdir(PUBLIC_UPLOADS_DIR, { recursive: true });
  } catch (err) {
    console.error("Failed to ensure institutions upload directory:", err);
  }
}

export const adminInstitutionsService = {
  async getDashboard() {
    const stats = await adminInstitutionsRepository.getStats();
    const { institutions } = await adminInstitutionsRepository.list({ limit: 6 });
    return {
      stats,
      recentInstitutions: institutions,
    };
  },

  async list(query) {
    return adminInstitutionsRepository.list(query);
  },

  async getById(id) {
    const institution = await adminInstitutionsRepository.getById(id);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }
    return institution;
  },

  async create(data, adminUser, reqMeta = {}) {
    // Unique code check
    const existing = await adminInstitutionsRepository.getByCode(data.institutionCode);
    if (existing) {
      const err = new Error(`Institution code '${data.institutionCode}' is already registered.`);
      err.statusCode = 400;
      throw err;
    }

    const id = await adminInstitutionsRepository.create(data);
    const created = await adminInstitutionsRepository.getById(id);

    // Audit log
    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.create",
      resourceType: "institution",
      resourceId: id,
      details: {
        name: created.name,
        code: created.institution_code,
        type: created.institution_type,
        status: created.status,
      },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return created;
  },

  async update(id, data, adminUser, reqMeta = {}) {
    const current = await adminInstitutionsRepository.getById(id);
    if (!current) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    if (data.institutionCode && data.institutionCode !== current.institution_code) {
      const existing = await adminInstitutionsRepository.getByCode(data.institutionCode);
      if (existing && Number(existing.id) !== Number(id)) {
        const err = new Error(`Institution code '${data.institutionCode}' is already registered to another institution.`);
        err.statusCode = 400;
        throw err;
      }
    }

    // Map camelCase to snake_case if present
    const payload = {};
    if (data.institutionCode !== undefined) payload.institution_code = data.institutionCode;
    if (data.name !== undefined) payload.name = data.name;
    if (data.institutionType !== undefined) payload.institution_type = data.institutionType;
    if (data.logoUrl !== undefined) payload.logo_url = data.logoUrl;
    if (data.description !== undefined) payload.description = data.description;
    if (data.websiteUrl !== undefined) payload.website_url = data.websiteUrl;
    if (data.supportEmail !== undefined) payload.support_email = data.supportEmail;
    if (data.supportPhone !== undefined) payload.support_phone = data.supportPhone;
    if (data.status !== undefined) payload.status = data.status;

    await adminInstitutionsRepository.update(id, payload);
    const updated = await adminInstitutionsRepository.getById(id);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.update",
      resourceType: "institution",
      resourceId: id,
      details: {
        before: { name: current.name, status: current.status },
        after: { name: updated.name, status: updated.status },
      },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return updated;
  },

  async updateStatus(id, newStatus, adminUser, reqMeta = {}) {
    const validStatuses = ["draft", "active", "inactive", "suspended"];
    if (!validStatuses.includes(newStatus)) {
      const err = new Error(`Invalid institution status: ${newStatus}`);
      err.statusCode = 400;
      throw err;
    }

    return this.update(id, { status: newStatus }, adminUser, reqMeta);
  },

  async delete(id, adminUser, reqMeta = {}) {
    const institution = await adminInstitutionsRepository.getById(id);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    const deps = await adminInstitutionsRepository.getDependencies(id);
    if (deps.usersCount > 0 || deps.servicesCount > 0 || deps.applicationsCount > 0) {
      const reasons = [];
      if (deps.usersCount > 0) reasons.push(`${deps.usersCount} staff user(s)`);
      if (deps.servicesCount > 0) reasons.push(`${deps.servicesCount} service(s)`);
      if (deps.applicationsCount > 0) reasons.push(`${deps.applicationsCount} linked application(s)`);

      const err = new Error(
        `Cannot permanently delete institution with associated records (${reasons.join(", ")}). Please deactivate or suspend the institution instead to preserve audit history.`
      );
      err.statusCode = 409;
      throw err;
    }

    await adminInstitutionsRepository.delete(id);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.delete",
      resourceType: "institution",
      resourceId: id,
      details: { name: institution.name, code: institution.institution_code },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: "Institution safely deleted." };
  },

  async uploadLogo(file) {
    if (!file) {
      const err = new Error("No image file uploaded");
      err.statusCode = 400;
      throw err;
    }

    await ensureUploadDir();

    const ext = path.extname(file.originalname).toLowerCase() || ".png";
    const randomHex = crypto.randomBytes(8).toString("hex");
    const safeFilename = `inst_${Date.now()}_${randomHex}${ext}`;
    const destinationPath = path.join(PUBLIC_UPLOADS_DIR, safeFilename);

    await fs.writeFile(destinationPath, file.buffer);

    const publicUrl = `/uploads/institutions/${safeFilename}`;
    return {
      filename: safeFilename,
      url: publicUrl,
    };
  },

  /* ========================================================================
     SERVICES MODULE
     ======================================================================== */

  async listServices(query) {
    return adminInstitutionsRepository.listServices(query);
  },

  async associateService(gatewayId, institutionId, adminUser, reqMeta = {}) {
    const institution = await adminInstitutionsRepository.getById(institutionId);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    await adminInstitutionsRepository.associateService(gatewayId, institutionId);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.service.associate",
      resourceType: "institution_service",
      resourceId: gatewayId,
      details: { institutionId, institutionName: institution.name },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: `Service linked to ${institution.name}` };
  },

  async disassociateService(gatewayId, adminUser, reqMeta = {}) {
    await adminInstitutionsRepository.disassociateService(gatewayId);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.service.disassociate",
      resourceType: "institution_service",
      resourceId: gatewayId,
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: "Service unlinked from institution" };
  },

  /* ========================================================================
     STAFF PROVISIONING & MEMBERSHIP
     ======================================================================== */

  async listStaff(query) {
    return adminInstitutionsRepository.listStaff(query);
  },

  async provisionStaff(
    { institutionId, email, phone = null, password, roleName, membershipStatus = "active" },
    adminUser,
    reqMeta = {}
  ) {
    const institution = await adminInstitutionsRepository.getById(institutionId);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    const validRoles = ["bank_admin", "bank_reviewer", "bank_operations"];
    if (!validRoles.includes(roleName)) {
      const err = new Error(`Invalid institution role. Must be one of: ${validRoles.join(", ")}`);
      err.statusCode = 400;
      throw err;
    }

    const [roleRows] = await db.query(`SELECT id, name FROM roles WHERE name = ? LIMIT 1`, [roleName]);
    if (!roleRows.length) {
      const err = new Error(`Role ${roleName} does not exist in system roles`);
      err.statusCode = 404;
      throw err;
    }
    const roleId = roleRows[0].id;

    // Execute in a database transaction
    const connection = await db.getConnection();
    await connection.beginTransaction();

    try {
      // 1. Check if user already exists or create new user
      const [existingUsers] = await connection.query(
        `SELECT id, email, status FROM users WHERE email = ? LIMIT 1`,
        [email.trim().toLowerCase()]
      );

      let userId;

      if (existingUsers.length > 0) {
        userId = existingUsers[0].id;

        // Check if user already assigned to THIS institution
        const [existingMembership] = await connection.query(
          `SELECT id FROM institution_users WHERE institution_id = ? AND user_id = ? LIMIT 1`,
          [institutionId, userId]
        );
        if (existingMembership.length > 0) {
          const err = new Error(`User '${email}' is already assigned to this institution.`);
          err.statusCode = 400;
          throw err;
        }
      } else {
        // Hash password with Argon2
        const passwordHash = await argon2.hash(password);

        const [userInsert] = await connection.execute(
          `
          INSERT INTO users (email, phone, password_hash, email_verified_at, status, created_at, updated_at)
          VALUES (?, ?, ?, NOW(), 'active', NOW(), NOW())
          `,
          [email.trim().toLowerCase(), phone ? phone.trim() : null, passwordHash]
        );
        userId = userInsert.insertId;
      }

      // 2. Assign application-level role
      await connection.execute(
        `
        INSERT INTO user_roles (user_id, role_id)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE role_id = VALUES(role_id)
        `,
        [userId, roleId]
      );

      // 3. Assign institution membership
      const [iuInsert] = await connection.execute(
        `
        INSERT INTO institution_users
          (institution_id, user_id, role_id, membership_status, created_by_user_id, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        `,
        [institutionId, userId, roleId, membershipStatus, adminUser?.id || null]
      );

      await connection.commit();

      await logAdminAudit({
        userId: adminUser?.id,
        adminEmail: adminUser?.email,
        action: "institution.user.provision",
        resourceType: "institution_user",
        resourceId: iuInsert.insertId,
        details: {
          institutionId,
          institutionName: institution.name,
          email,
          role: roleName,
          status: membershipStatus,
        },
        ip: reqMeta.ip,
        userAgent: reqMeta.userAgent,
      });

      return {
        membershipId: iuInsert.insertId,
        userId,
        email,
        roleName,
        membershipStatus,
      };
    } catch (err) {
      await connection.rollback();
      throw err;
    } finally {
      connection.release();
    }
  },

  async updateStaffMembership(membershipId, { roleName, membershipStatus }, adminUser, reqMeta = {}) {
    const membership = await adminInstitutionsRepository.getStaffMembership(membershipId);
    if (!membership) {
      const err = new Error("Staff membership record not found");
      err.statusCode = 404;
      throw err;
    }

    let roleId = null;
    if (roleName) {
      const [roleRows] = await db.query(`SELECT id FROM roles WHERE name = ? LIMIT 1`, [roleName]);
      if (!roleRows.length) {
        const err = new Error(`Role ${roleName} does not exist`);
        err.statusCode = 400;
        throw err;
      }
      roleId = roleRows[0].id;

      // Update in user_roles as well
      await db.execute(`UPDATE user_roles SET role_id = ? WHERE user_id = ?`, [roleId, membership.user_id]);
    }

    await adminInstitutionsRepository.updateStaffMembership(membershipId, {
      roleId,
      membershipStatus,
    });

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.user.update",
      resourceType: "institution_user",
      resourceId: membershipId,
      details: { roleName, membershipStatus },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: "Staff membership updated successfully" };
  },

  /* ========================================================================
     KYC REQUIREMENTS MODULE
     ======================================================================== */

  async listKycRequirements(query) {
    return adminInstitutionsRepository.listKycRequirements(query);
  },

  async createKycRequirement(data, adminUser, reqMeta = {}) {
    const id = await adminInstitutionsRepository.createKycRequirement(data);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.kyc_requirement.create",
      resourceType: "institution_kyc_requirement",
      resourceId: id,
      details: { name: data.name, institutionId: data.institutionId },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { id, ...data };
  },

  async updateKycRequirement(id, data, adminUser, reqMeta = {}) {
    await adminInstitutionsRepository.updateKycRequirement(id, data);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.kyc_requirement.update",
      resourceType: "institution_kyc_requirement",
      resourceId: id,
      details: data,
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true };
  },

  async deleteKycRequirement(id, adminUser, reqMeta = {}) {
    await adminInstitutionsRepository.deleteKycRequirement(id);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.kyc_requirement.delete",
      resourceType: "institution_kyc_requirement",
      resourceId: id,
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true };
  },

  /* ========================================================================
     SETTINGS MODULE
     ======================================================================== */

  async getSettings(institutionId) {
    const institution = await adminInstitutionsRepository.getById(institutionId);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    const settings = await adminInstitutionsRepository.getSettings(institutionId);
    return {
      institution,
      settings,
    };
  },

  async saveSettings(institutionId, settingsPayload, adminUser, reqMeta = {}) {
    const institution = await adminInstitutionsRepository.getById(institutionId);
    if (!institution) {
      const err = new Error("Institution not found");
      err.statusCode = 404;
      throw err;
    }

    for (const [key, value] of Object.entries(settingsPayload)) {
      await adminInstitutionsRepository.saveSetting(
        institutionId,
        key,
        value,
        adminUser?.email || "Admin"
      );
    }

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.settings.update",
      resourceType: "institution",
      resourceId: institutionId,
      details: { keys: Object.keys(settingsPayload) },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: "Institution settings saved successfully" };
  },
  /* ========================================================================
     BRANCHES & LOCATIONS MODULE
     ======================================================================== */

  async getBranchStats(institutionId) {
    return adminInstitutionsRepository.getBranchStats(institutionId);
  },

  async listBranches(institutionId, query) {
    return adminInstitutionsRepository.listBranches(institutionId, query);
  },

  async getBranchById(branchId) {
    const branch = await adminInstitutionsRepository.getBranchById(branchId);
    if (!branch) {
      const err = new Error("Branch not found");
      err.statusCode = 404;
      throw err;
    }
    return branch;
  },

  async createBranch(data, adminUser, reqMeta = {}) {
    // Check if code is already taken for this institution
    const existing = await adminInstitutionsRepository.getBranchByCode(data.institutionId, data.branchCode);
    if (existing) {
      const err = new Error(`Branch code '${data.branchCode}' is already registered for this institution.`);
      err.statusCode = 400;
      throw err;
    }

    const id = await adminInstitutionsRepository.createBranch(data);
    const branch = await adminInstitutionsRepository.getBranchById(id);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.branch.create",
      resourceType: "institution_branch",
      resourceId: id,
      details: {
        institutionId: data.institutionId,
        branchName: data.branchName,
        branchCode: data.branchCode,
        division: data.division,
        district: data.district,
      },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return branch;
  },

  async updateBranch(branchId, data, adminUser, reqMeta = {}) {
    const current = await adminInstitutionsRepository.getBranchById(branchId);
    if (!current) {
      const err = new Error("Branch not found");
      err.statusCode = 404;
      throw err;
    }

    if (data.branchCode && data.branchCode !== current.branch_code) {
      const existing = await adminInstitutionsRepository.getBranchByCode(current.institution_id, data.branchCode);
      if (existing && Number(existing.id) !== Number(branchId)) {
        const err = new Error(`Branch code '${data.branchCode}' is already used by another branch in this institution.`);
        err.statusCode = 400;
        throw err;
      }
    }

    await adminInstitutionsRepository.updateBranch(branchId, data);
    const updated = await adminInstitutionsRepository.getBranchById(branchId);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.branch.update",
      resourceType: "institution_branch",
      resourceId: branchId,
      details: {
        branchName: updated.branch_name,
        branchCode: updated.branch_code,
      },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return updated;
  },

  async updateBranchStatus(branchId, status, adminUser, reqMeta = {}) {
    const current = await adminInstitutionsRepository.getBranchById(branchId);
    if (!current) {
      const err = new Error("Branch not found");
      err.statusCode = 404;
      throw err;
    }

    await adminInstitutionsRepository.updateBranchStatus(branchId, status);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.branch.status",
      resourceType: "institution_branch",
      resourceId: branchId,
      details: { previousStatus: current.status, newStatus: status },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: `Branch status updated to ${status}` };
  },

  async deleteBranch(branchId, adminUser, reqMeta = {}) {
    const current = await adminInstitutionsRepository.getBranchById(branchId);
    if (!current) {
      const err = new Error("Branch not found");
      err.statusCode = 404;
      throw err;
    }

    await adminInstitutionsRepository.deleteBranch(branchId);

    await logAdminAudit({
      userId: adminUser?.id,
      adminEmail: adminUser?.email,
      action: "institution.branch.delete",
      resourceType: "institution_branch",
      resourceId: branchId,
      details: { branchName: current.branch_name, branchCode: current.branch_code },
      ip: reqMeta.ip,
      userAgent: reqMeta.userAgent,
    });

    return { success: true, message: "Branch deleted successfully" };
  },

  async exportBranchesCsv(institutionId) {
    const result = await adminInstitutionsRepository.listBranches(institutionId, {
      division: "all",
      district: "all",
      upazila: "all",
      status: "all",
      search: "",
      page: 1,
      limit: 10000,
    });

    const rows = result.branches || [];
    const headers = [
      "Branch ID",
      "Branch Name",
      "Branch Code",
      "Division",
      "District",
      "Upazila",
      "Post Office",
      "Postal Code",
      "Address",
      "Phone",
      "Email",
      "Manager Name",
      "Status",
      "Created At",
    ];

    const csvLines = [headers.join(",")];
    for (const b of rows) {
      const escape = (val) => {
        if (val === null || val === undefined) return '""';
        const str = String(val).replace(/"/g, '""');
        return `"${str}"`;
      };

      csvLines.push([
        escape(b.id),
        escape(b.branch_name),
        escape(b.branch_code),
        escape(b.division),
        escape(b.district),
        escape(b.upazila),
        escape(b.post_office),
        escape(b.postal_code),
        escape(b.address),
        escape(b.phone),
        escape(b.email),
        escape(b.manager_name),
        escape(b.status),
        escape(b.created_at),
      ].join(","));
    }

    return csvLines.join("\r\n");
  },

  /* ========================================================================
     GEOGRAPHIC MASTER DATA
     ======================================================================== */

  async getGeoDivisions() {
    return adminInstitutionsRepository.getGeoDivisions();
  },

  async getGeoDistricts(divisionIdOrName) {
    return adminInstitutionsRepository.getGeoDistricts(divisionIdOrName);
  },

  async getGeoUpazilas(districtIdOrName) {
    return adminInstitutionsRepository.getGeoUpazilas(districtIdOrName);
  },

  /* ========================================================================
     APPLICATIONS MODULE
     ======================================================================== */

  async listInstitutionApplications(institutionId, query) {
    return adminInstitutionsRepository.listInstitutionApplications(institutionId, query);
  },

  async getInstitutionApplicationStats(institutionId) {
    return adminInstitutionsRepository.getInstitutionApplicationStats(institutionId);
  },
};


