import { db } from "../../../config/db.js";

export const adminInstitutionsRepository = {
  /**
   * Summary KPI Statistics from real database counts
   */
  async getStats() {
    const [instRows] = await db.query(`
      SELECT
        COUNT(*) AS total_institutions,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_institutions,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_institutions,
        SUM(CASE WHEN status IN ('inactive', 'suspended') THEN 1 ELSE 0 END) AS inactive_institutions
      FROM institutions
    `);

    const [userRows] = await db.query(`
      SELECT COUNT(DISTINCT user_id) AS total_users
      FROM institution_users
      WHERE membership_status = 'active'
    `);

    const [appRows] = await db.query(`
      SELECT COUNT(*) AS total_applications
      FROM merchant_gateway_applications
      WHERE institution_id IS NOT NULL
    `);

    const totalInstitutions = Number(instRows[0]?.total_institutions || 0);
    const activeInstitutions = Number(instRows[0]?.active_institutions || 0);
    const draftInstitutions = Number(instRows[0]?.draft_institutions || 0);
    const inactiveInstitutions = Number(instRows[0]?.inactive_institutions || 0);
    const totalUsers = Number(userRows[0]?.total_users || 0);
    const totalApplications = Number(appRows[0]?.total_applications || 0);

    return {
      totalInstitutions,
      activeInstitutions,
      draftInstitutions,
      inactiveInstitutions,
      totalUsers,
      totalApplications,
    };
  },

  /**
   * List Institutions with search, filters, pagination and real linked staff & service counts
   */
  async list({ search = "", type = "all", status = "all", page = 1, limit = 15 }) {
    const conditions = [];
    const params = [];

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(i.name LIKE ? OR i.institution_code LIKE ? OR i.support_email LIKE ?)");
      params.push(term, term, term);
    }

    if (type && type !== "all") {
      conditions.push("i.institution_type = ?");
      params.push(type);
    }

    if (status && status !== "all") {
      conditions.push("i.status = ?");
      params.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `SELECT COUNT(*) AS total FROM institutions i ${where}`,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        i.*,
        COUNT(DISTINCT iu.id) AS staff_count,
        COUNT(DISTINCT g.id) AS service_count,
        COUNT(DISTINCT mga.id) AS linked_application_count,
        COUNT(DISTINCT b.id) AS branches_count
      FROM institutions i
      LEFT JOIN institution_users iu ON iu.institution_id = i.id AND iu.membership_status = 'active'
      LEFT JOIN gateways g ON g.institution_id = i.id
      LEFT JOIN merchant_gateway_applications mga ON mga.institution_id = i.id
      LEFT JOIN institution_branches b ON b.institution_id = i.id
      ${where}
      GROUP BY i.id
      ORDER BY i.created_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    for (const row of rows) {
      const [svcRows] = await db.query(
        `SELECT id, name, code, service_type, status FROM gateways WHERE institution_id = ? LIMIT 3`,
        [row.id]
      );
      row.services = svcRows;
    }

    return {
      institutions: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  /**
   * Find single institution by ID with full details
   */
  async getById(id) {
    const validId = Number(id);
    if (!validId || isNaN(validId)) return null;

    const [rows] = await db.query(
      `
      SELECT
        i.*,
        COUNT(DISTINCT iu.id) AS staff_count,
        COUNT(DISTINCT g.id) AS service_count,
        COUNT(DISTINCT mga.id) AS linked_application_count,
        COUNT(DISTINCT b.id) AS branches_count
      FROM institutions i
      LEFT JOIN institution_users iu ON iu.institution_id = i.id AND iu.membership_status = 'active'
      LEFT JOIN gateways g ON g.institution_id = i.id
      LEFT JOIN merchant_gateway_applications mga ON mga.institution_id = i.id
      LEFT JOIN institution_branches b ON b.institution_id = i.id
      WHERE i.id = ?
      GROUP BY i.id
      LIMIT 1
      `,
      [validId]
    );

    return rows[0] || null;
  },

  /**
   * Find institution by code for unique check
   */
  async getByCode(code) {
    const [rows] = await db.query(`SELECT * FROM institutions WHERE institution_code = ? LIMIT 1`, [code]);
    return rows[0] || null;
  },

  /**
   * Create new institution
   */
  async create({
    institutionCode,
    name,
    institutionType = "bank",
    logoUrl = null,
    description = null,
    websiteUrl = null,
    supportEmail = null,
    supportPhone = null,
    status = "draft",
  }) {
    const [res] = await db.execute(
      `
      INSERT INTO institutions
        (institution_code, name, institution_type, logo_url, description, website_url, support_email, support_phone, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        institutionCode,
        name,
        institutionType,
        logoUrl,
        description,
        websiteUrl,
        supportEmail,
        supportPhone,
        status,
      ]
    );

    return res.insertId;
  },

  /**
   * Update institution details
   */
  async update(id, data) {
    const updates = [];
    const params = [];

    const allowedFields = [
      "institution_code",
      "name",
      "institution_type",
      "logo_url",
      "description",
      "website_url",
      "support_email",
      "support_phone",
      "status",
    ];

    const mapped = {
      institution_code: data.institutionCode || data.code,
      name: data.name,
      institution_type: data.institutionType || data.type,
      logo_url: data.logoUrl,
      description: data.description,
      website_url: data.websiteUrl,
      support_email: data.supportEmail || data.contactEmail,
      support_phone: data.supportPhone || data.contactPhone,
      status: data.status,
    };

    for (const [col, val] of Object.entries(mapped)) {
      if (val !== undefined && allowedFields.includes(col)) {
        updates.push(`\`${col}\` = ?`);
        params.push(val);
      }
    }

    if (!updates.length) return false;

    updates.push("updated_at = NOW()");
    params.push(id);

    await db.execute(`UPDATE institutions SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  /**
   * Check dependent records before safe delete
   */
  async getDependencies(id) {
    const [users] = await db.query(`SELECT COUNT(*) AS c FROM institution_users WHERE institution_id = ?`, [id]);
    const [services] = await db.query(`SELECT COUNT(*) AS c FROM gateways WHERE institution_id = ?`, [id]);
    const [applications] = await db.query(
      `SELECT COUNT(*) AS c FROM merchant_gateway_applications WHERE institution_id = ?`,
      [id]
    );
    const [branches] = await db.query(
      `SELECT COUNT(*) AS c FROM institution_branches WHERE institution_id = ?`,
      [id]
    );

    return {
      usersCount: Number(users[0]?.c || 0),
      servicesCount: Number(services[0]?.c || 0),
      applicationsCount: Number(applications[0]?.c || 0),
      branchesCount: Number(branches[0]?.c || 0),
    };
  },

  /**
   * Delete institution permanently if safe
   */
  async delete(id) {
    await db.execute(`DELETE FROM institutions WHERE id = ?`, [id]);
    return true;
  },

  /* ========================================================================
     INSTITUTION SERVICES MANAGEMENT
     ======================================================================== */

  async listServices({ institutionId = null, status = "all", search = "", page = 1, limit = 20 }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("g.institution_id = ?");
      params.push(validInstId);
    }

    if (status && status !== "all") {
      conditions.push("g.status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(g.name LIKE ? OR g.code LIKE ? OR i.name LIKE ?)");
      params.push(term, term, term);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM gateways g
      LEFT JOIN institutions i ON i.id = g.institution_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        g.*,
        i.name AS institution_name,
        i.institution_code,
        i.institution_type
      FROM gateways g
      LEFT JOIN institutions i ON i.id = g.institution_id
      ${where}
      ORDER BY g.display_order ASC, g.id DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      services: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async associateService(gatewayId, institutionId) {
    const validInstId = Number(institutionId);
    await db.execute(
      `UPDATE gateways SET institution_id = ?, updated_at = NOW() WHERE id = ?`,
      [validInstId, gatewayId]
    );
    return true;
  },

  async disassociateService(gatewayId) {
    await db.execute(
      `UPDATE gateways SET institution_id = NULL, updated_at = NOW() WHERE id = ?`,
      [gatewayId]
    );
    return true;
  },

  /* ========================================================================
     INSTITUTION USERS / STAFF MANAGEMENT
     ======================================================================== */

  async listStaff({ institutionId = null, status = "all", search = "", page = 1, limit = 20 }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("iu.institution_id = ?");
      params.push(validInstId);
    }

    if (status && status !== "all") {
      conditions.push("iu.membership_status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(u.email LIKE ? OR u.phone LIKE ? OR i.name LIKE ? OR r.name LIKE ?)");
      params.push(term, term, term, term);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        iu.id AS membership_id,
        iu.membership_status,
        iu.created_at AS joined_at,
        u.id AS user_id,
        u.email,
        u.phone,
        u.status AS user_status,
        r.id AS role_id,
        r.name AS role_name,
        r.description AS role_description,
        i.id AS institution_id,
        i.name AS institution_name,
        i.institution_code,
        i.institution_type
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      ${where}
      ORDER BY iu.created_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      staff: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getStaffMembership(membershipId) {
    return this.getStaffById(membershipId);
  },

  async getStaffById(membershipId) {
    const [rows] = await db.query(
      `
      SELECT
        iu.id AS membership_id,
        iu.membership_status,
        iu.created_at AS joined_at,
        u.id AS user_id,
        u.email,
        u.phone,
        u.status AS user_status,
        r.id AS role_id,
        r.name AS role_name,
        i.id AS institution_id,
        i.name AS institution_name,
        i.institution_code
      FROM institution_users iu
      JOIN users u ON u.id = iu.user_id
      JOIN roles r ON r.id = iu.role_id
      JOIN institutions i ON i.id = iu.institution_id
      WHERE iu.id = ?
      LIMIT 1
      `,
      [membershipId]
    );
    return rows[0] || null;
  },

  async createStaffMembership({ userId, institutionId, roleId, membershipStatus = "active" }) {
    const [res] = await db.execute(
      `
      INSERT INTO institution_users (user_id, institution_id, role_id, membership_status, created_at, updated_at)
      VALUES (?, ?, ?, ?, NOW(), NOW())
      `,
      [userId, institutionId, roleId, membershipStatus]
    );
    return res.insertId;
  },

  async updateStaffMembership(membershipId, { roleId = null, membershipStatus = null }) {
    const updates = [];
    const params = [];

    if (roleId) {
      updates.push("role_id = ?");
      params.push(roleId);
    }
    if (membershipStatus) {
      updates.push("membership_status = ?");
      params.push(membershipStatus);
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(membershipId);

    await db.execute(`UPDATE institution_users SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  /* ========================================================================
     BRANCHES & LOCATIONS MANAGEMENT
     ======================================================================== */

  async getBranchStats(institutionId) {
    const validInstId = Number(institutionId);
    const [rows] = await db.query(
      `
      SELECT
        COUNT(*) AS total_branches,
        COUNT(DISTINCT division) AS divisions_count,
        COUNT(DISTINCT district) AS districts_count,
        COALESCE(SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END), 0) AS active_branches,
        COALESCE(SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END), 0) AS inactive_branches
      FROM institution_branches
      WHERE institution_id = ?
      `,
      [validInstId]
    );

    const r = rows[0] || {};
    return {
      totalBranches: Number(r.total_branches || 0),
      divisionsCount: Number(r.divisions_count || 0),
      districtsCount: Number(r.districts_count || 0),
      activeBranches: Number(r.active_branches || 0),
      inactiveBranches: Number(r.inactive_branches || 0),
    };
  },

  async listBranches(institutionId, { division = "all", district = "all", upazila = "all", status = "all", search = "", page = 1, limit = 15 }) {
    const validInstId = Number(institutionId);
    const conditions = ["b.institution_id = ?"];
    const params = [validInstId];

    if (division && division !== "all") {
      conditions.push("b.division = ?");
      params.push(division);
    }
    if (district && district !== "all") {
      conditions.push("b.district = ?");
      params.push(district);
    }
    if (upazila && upazila !== "all") {
      conditions.push("b.upazila = ?");
      params.push(upazila);
    }
    if (status && status !== "all") {
      conditions.push("b.status = ?");
      params.push(status);
    }
    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(b.branch_name LIKE ? OR b.branch_code LIKE ? OR b.address LIKE ? OR b.phone LIKE ? OR b.manager_name LIKE ?)");
      params.push(term, term, term, term, term);
    }

    const where = `WHERE ${conditions.join(" AND ")}`;
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `SELECT COUNT(*) AS total FROM institution_branches b ${where}`,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT b.*, i.name AS institution_name, i.institution_code
      FROM institution_branches b
      JOIN institutions i ON i.id = b.institution_id
      ${where}
      ORDER BY b.created_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      branches: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getBranchById(branchId) {
    const [rows] = await db.query(`SELECT * FROM institution_branches WHERE id = ? LIMIT 1`, [branchId]);
    return rows[0] || null;
  },

  async getBranchByCode(institutionId, branchCode) {
    const [rows] = await db.query(
      `SELECT * FROM institution_branches WHERE institution_id = ? AND branch_code = ? LIMIT 1`,
      [institutionId, branchCode]
    );
    return rows[0] || null;
  },

  async createBranch(data) {
    const [res] = await db.execute(
      `
      INSERT INTO institution_branches
        (institution_id, branch_name, branch_code, division, district, upazila, post_office, postal_code, address, phone, email, manager_name, notes, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        data.institutionId,
        data.branchName,
        data.branchCode,
        data.division,
        data.district,
        data.upazila,
        data.postOffice || null,
        data.postalCode || null,
        data.address || null,
        data.phone || null,
        data.email || null,
        data.managerName || null,
        data.notes || null,
        data.status || "active",
      ]
    );
    return res.insertId;
  },

  async updateBranch(branchId, data) {
    const updates = [];
    const params = [];

    const fieldMap = {
      branchName: "branch_name",
      branchCode: "branch_code",
      division: "division",
      district: "district",
      upazila: "upazila",
      postOffice: "post_office",
      postalCode: "postal_code",
      address: "address",
      phone: "phone",
      email: "email",
      managerName: "manager_name",
      notes: "notes",
      status: "status",
    };

    for (const [key, col] of Object.entries(fieldMap)) {
      if (data[key] !== undefined) {
        updates.push(`\`${col}\` = ?`);
        params.push(data[key]);
      }
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(branchId);

    await db.execute(`UPDATE institution_branches SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  async updateBranchStatus(branchId, status) {
    await db.execute(`UPDATE institution_branches SET status = ?, updated_at = NOW() WHERE id = ?`, [status, branchId]);
    return true;
  },

  async deleteBranch(branchId) {
    const [appCheck] = await db.query(
      `SELECT COUNT(*) AS c FROM merchant_gateway_applications WHERE branch_id = ?`,
      [branchId]
    );
    if (appCheck[0]?.c > 0) {
      const err = new Error(`Cannot delete branch referenced by ${appCheck[0].c} merchant application(s). Mark it as Inactive instead.`);
      err.statusCode = 409;
      throw err;
    }

    await db.execute(`DELETE FROM institution_branches WHERE id = ?`, [branchId]);
    return true;
  },

  /* ========================================================================
     BANGLADESH GEOGRAPHIC MASTER DATA
     ======================================================================== */

  async getGeoDivisions() {
    const [rows] = await db.query(`SELECT id, name, name_bn FROM geo_divisions ORDER BY name ASC`);
    return rows;
  },

  async getGeoDistricts(divisionIdOrName = null) {
    let where = "";
    const params = [];

    if (divisionIdOrName) {
      if (!isNaN(Number(divisionIdOrName))) {
        where = "WHERE d.division_id = ?";
        params.push(Number(divisionIdOrName));
      } else {
        where = "WHERE gdiv.name = ?";
        params.push(String(divisionIdOrName).trim());
      }
    }

    const [rows] = await db.query(
      `
      SELECT d.id, d.division_id, d.name, d.name_bn, gdiv.name AS division_name
      FROM geo_districts d
      JOIN geo_divisions gdiv ON gdiv.id = d.division_id
      ${where}
      ORDER BY d.name ASC
      `,
      params
    );
    return rows;
  },

  async getGeoUpazilas(districtIdOrName = null) {
    let where = "";
    const params = [];

    if (districtIdOrName) {
      if (!isNaN(Number(districtIdOrName))) {
        where = "WHERE u.district_id = ?";
        params.push(Number(districtIdOrName));
      } else {
        where = "WHERE gdist.name = ?";
        params.push(String(districtIdOrName).trim());
      }
    }

    const [rows] = await db.query(
      `
      SELECT u.id, u.district_id, u.name, u.name_bn, gdist.name AS district_name
      FROM geo_upazilas u
      JOIN geo_districts gdist ON gdist.id = u.district_id
      ${where}
      ORDER BY u.name ASC
      `,
      params
    );
    return rows;
  },

  /* ========================================================================
     INSTITUTION KYC REQUIREMENTS MANAGEMENT (EXPANDED DYNAMIC MODULE)
     ======================================================================== */

  async listKycRequirements({ institutionId = null, category = "all", status = "all" }) {
    const conditions = [];
    const params = [];

    const validInstId =
      institutionId !== null &&
      institutionId !== undefined &&
      !isNaN(Number(institutionId)) &&
      Number(institutionId) > 0
        ? Math.floor(Number(institutionId))
        : null;

    if (validInstId) {
      conditions.push("ikr.institution_id = ?");
      params.push(validInstId);
    }

    if (category && category !== "all") {
      conditions.push("ikr.requirement_category = ?");
      params.push(category);
    }

    if (status && status !== "all") {
      conditions.push("ikr.status = ?");
      params.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const [rows] = await db.query(
      `
      SELECT
        ikr.*,
        i.name AS institution_name,
        i.institution_code
      FROM institution_kyc_requirements ikr
      JOIN institutions i ON i.id = ikr.institution_id
      ${where}
      ORDER BY ikr.display_order ASC, ikr.id ASC
      `,
      params
    );

    return rows;
  },

  async createKycRequirement({
    institutionId,
    name,
    requirementCode,
    requirementCategory = "business_identity",
    requirementType = "document_upload",
    applicableBusinessTypes = null,
    documentType = "other",
    description = null,
    instructions = null,
    allowedExtensions = "pdf,jpg,jpeg,png,webp",
    maxFileSizeMb = 5,
    maxFilesCount = 1,
    documentSides = "single",
    isMandatory = true,
    requiresApproval = true,
    reviewInstructions = null,
    status = "active",
    displayOrder = 0,
  }) {
    const businessTypesStr = Array.isArray(applicableBusinessTypes)
      ? JSON.stringify(applicableBusinessTypes)
      : applicableBusinessTypes;

    const [res] = await db.execute(
      `
      INSERT INTO institution_kyc_requirements
        (institution_id, name, requirement_code, requirement_category, requirement_type, applicable_business_types, document_type, description, instructions, allowed_extensions, max_file_size_mb, max_files_count, document_sides, is_mandatory, requires_approval, review_instructions, status, display_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        institutionId,
        name,
        requirementCode,
        requirementCategory,
        requirementType,
        businessTypesStr,
        documentType || "other",
        description,
        instructions,
        allowedExtensions,
        maxFileSizeMb,
        maxFilesCount,
        documentSides,
        isMandatory ? 1 : 0,
        requiresApproval ? 1 : 0,
        reviewInstructions,
        status,
        displayOrder,
      ]
    );

    return res.insertId;
  },

  async updateKycRequirement(id, data) {
    const updates = [];
    const params = [];

    const fieldMap = {
      institutionId: "institution_id",
      name: "name",
      requirementCode: "requirement_code",
      requirementCategory: "requirement_category",
      requirementType: "requirement_type",
      applicableBusinessTypes: "applicable_business_types",
      documentType: "document_type",
      description: "description",
      instructions: "instructions",
      allowedExtensions: "allowed_extensions",
      maxFileSizeMb: "max_file_size_mb",
      maxFilesCount: "max_files_count",
      documentSides: "document_sides",
      isMandatory: "is_mandatory",
      requiresApproval: "requires_approval",
      reviewInstructions: "review_instructions",
      status: "status",
      displayOrder: "display_order",
    };

    for (const [key, col] of Object.entries(fieldMap)) {
      if (data[key] !== undefined) {
        let val = data[key];
        if (key === "applicableBusinessTypes" && Array.isArray(val)) {
          val = JSON.stringify(val);
        } else if (key === "isMandatory" || key === "requiresApproval") {
          val = val ? 1 : 0;
        }
        updates.push(`\`${col}\` = ?`);
        params.push(val);
      }
    }

    if (!updates.length) return false;
    updates.push("updated_at = NOW()");
    params.push(id);

    await db.execute(`UPDATE institution_kyc_requirements SET ${updates.join(", ")} WHERE id = ?`, params);
    return true;
  },

  async deleteKycRequirement(id) {
    await db.execute(`DELETE FROM institution_kyc_requirements WHERE id = ?`, [id]);
    return true;
  },

  /* ========================================================================
     INSTITUTION MERCHANT APPLICATIONS
     ======================================================================== */

  async listInstitutionApplications(institutionId, { status = "all", search = "", page = 1, limit = 15 }) {
    const validInstId = Number(institutionId);
    const conditions = ["mga.institution_id = ?"];
    const params = [validInstId];

    if (status && status !== "all") {
      conditions.push("mga.status = ?");
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push("(m.business_name LIKE ? OR m.trade_license_number LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR g.name LIKE ?)");
      params.push(term, term, term, term, term);
    }

    const where = `WHERE ${conditions.join(" AND ")}`;
    const offset = (Math.max(1, page) - 1) * limit;

    const [countRows] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM merchant_gateway_applications mga
      JOIN merchants m ON m.id = mga.merchant_id
      JOIN users u ON u.id = m.user_id
      LEFT JOIN gateways g ON g.id = mga.gateway_id
      ${where}
      `,
      params
    );
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await db.query(
      `
      SELECT
        mga.id AS application_id,
        mga.status AS application_status,
        mga.applied_at,
        mga.reviewed_at,
        mga.review_note,
        m.id AS merchant_id,
        m.business_name,
        m.trade_license_number,
        u.email AS merchant_email,
        u.phone AS merchant_phone,
        g.id AS gateway_id,
        g.name AS gateway_name,
        g.code AS gateway_code,
        b.id AS branch_id,
        b.branch_name,
        b.branch_code
      FROM merchant_gateway_applications mga
      JOIN merchants m ON m.id = mga.merchant_id
      JOIN users u ON u.id = m.user_id
      LEFT JOIN gateways g ON g.id = mga.gateway_id
      LEFT JOIN institution_branches b ON b.id = mga.branch_id
      ${where}
      ORDER BY mga.applied_at DESC
      LIMIT ? OFFSET ?
      `,
      [...params, Number(limit), Number(offset)]
    );

    return {
      applications: rows,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  },

  async getInstitutionApplicationStats(institutionId) {
    const validInstId = Number(institutionId);
    const [rows] = await db.query(
      `
      SELECT
        COUNT(*) AS total_applications,
        COALESCE(SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END), 0) AS pending_applications,
        COALESCE(SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END), 0) AS under_review_applications,
        COALESCE(SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END), 0) AS approved_applications,
        COALESCE(SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END), 0) AS rejected_applications,
        COALESCE(SUM(CASE WHEN status = 'additional_information_required' THEN 1 ELSE 0 END), 0) AS info_required_applications
      FROM merchant_gateway_applications
      WHERE institution_id = ?
      `,
      [validInstId]
    );

    const r = rows[0] || {};
    return {
      totalApplications: Number(r.total_applications || 0),
      pendingApplications: Number(r.pending_applications || 0),
      underReviewApplications: Number(r.under_review_applications || 0),
      approvedApplications: Number(r.approved_applications || 0),
      rejectedApplications: Number(r.rejected_applications || 0),
      infoRequiredApplications: Number(r.info_required_applications || 0),
    };
  },

  /* ========================================================================
     INSTITUTION SETTINGS MANAGEMENT
     ======================================================================== */

  async getSettings(institutionId) {
    const validInstId = Number(institutionId);
    if (!validInstId || isNaN(validInstId)) return {};

    const [rows] = await db.query(
      `SELECT * FROM institution_settings WHERE institution_id = ?`,
      [validInstId]
    );

    const result = {};
    for (const row of rows) {
      let val = row.setting_value;
      if (typeof val === "string") {
        try {
          val = JSON.parse(val);
        } catch (_) {}
      }
      result[row.setting_key] = val;
    }
    return result;
  },

  async saveSetting(institutionId, settingKey, settingValue, updatedBy = "Admin") {
    const validInstId = Number(institutionId);
    if (!validInstId || isNaN(validInstId)) return false;

    let jsonStr;
    try {
      jsonStr = JSON.stringify(settingValue);
    } catch (_) {
      jsonStr = JSON.stringify(String(settingValue));
    }

    await db.execute(
      `
      INSERT INTO institution_settings (institution_id, setting_key, setting_value, updated_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        setting_value = VALUES(setting_value),
        updated_by = VALUES(updated_by),
        updated_at = NOW()
      `,
      [validInstId, settingKey, jsonStr, updatedBy]
    );

    return true;
  },
};
