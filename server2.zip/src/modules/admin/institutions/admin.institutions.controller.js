import { z } from "zod";
import { adminInstitutionsService } from "./admin.institutions.service.js";

const institutionSchema = z.preprocess(
  (val) => {
    if (typeof val !== "object" || val === null) return val;
    const p = { ...val };

    // Support both 'institutionCode' and 'code'
    if (!p.institutionCode && p.code) {
      p.institutionCode = String(p.code).trim().toUpperCase();
    } else if (p.institutionCode) {
      p.institutionCode = String(p.institutionCode).trim().toUpperCase();
    }

    if (p.name) {
      p.name = String(p.name).trim();
    }

    // Map institutionType from any alias (commercial_bank, islamic_bank, mfs, psp, etc.)
    const rawType = String(p.institutionType || p.type || "bank").toLowerCase();
    if (["commercial_bank", "islamic_bank", "nbfi", "bank"].includes(rawType)) {
      p.institutionType = "bank";
    } else if (["mfs"].includes(rawType)) {
      p.institutionType = "mfs";
    } else if (["psp", "payment_gateway"].includes(rawType)) {
      p.institutionType = "payment_gateway";
    } else {
      p.institutionType = "other";
    }

    // Support both 'supportEmail' and 'contactEmail'
    if (p.supportEmail === undefined && p.contactEmail !== undefined) {
      p.supportEmail = p.contactEmail ? String(p.contactEmail).trim() : null;
    } else if (p.supportEmail) {
      p.supportEmail = String(p.supportEmail).trim();
    }

    // Support both 'supportPhone' and 'contactPhone'
    if (p.supportPhone === undefined && p.contactPhone !== undefined) {
      p.supportPhone = p.contactPhone ? String(p.contactPhone).trim() : null;
    } else if (p.supportPhone) {
      p.supportPhone = String(p.supportPhone).trim();
    }

    if (p.websiteUrl) p.websiteUrl = String(p.websiteUrl).trim();
    if (p.logoUrl) p.logoUrl = String(p.logoUrl).trim();

    return p;
  },
  z.object({
    name: z.string().min(2, "Institution name must be at least 2 characters"),
    institutionCode: z
      .string()
      .min(2, "Institution code must be at least 2 characters")
      .regex(/^[A-Z0-9_-]+$/i, "Institution code must contain only letters, numbers, underscores and hyphens"),
    institutionType: z.enum(["bank", "mfs", "payment_gateway", "other"]).default("bank"),
    logoUrl: z.string().optional().nullable().or(z.literal("")),
    description: z.string().optional().nullable().or(z.literal("")),
    websiteUrl: z.string().optional().nullable().or(z.literal("")),
    supportEmail: z.string().email("Invalid support email").optional().nullable().or(z.literal("")),
    supportPhone: z.string().optional().nullable().or(z.literal("")),
    status: z.enum(["draft", "active", "inactive", "suspended"]).default("draft"),
  })
);

const staffSchema = z.preprocess(
  (val) => {
    if (typeof val !== "object" || val === null) return val;
    const p = { ...val };
    if (!p.roleName && p.role) {
      p.roleName = p.role;
    }
    return p;
  },
  z.object({
    institutionId: z.coerce.number().positive("Institution ID is required"),
    email: z.string().email("Valid email required"),
    phone: z.string().optional().nullable().or(z.literal("")),
    password: z.string().min(6, "Password must be at least 6 characters"),
    roleName: z.enum(["bank_admin", "bank_reviewer", "bank_operations"]),
    membershipStatus: z.enum(["active", "inactive", "suspended"]).default("active"),
  })
);

const branchSchema = z.preprocess(
  (val) => {
    if (typeof val !== "object" || val === null) return val;
    const p = { ...val };
    if (p.branchCode) p.branchCode = String(p.branchCode).trim().toUpperCase();
    if (p.branchName) p.branchName = String(p.branchName).trim();
    if (p.email === "") p.email = null;
    if (p.phone === "") p.phone = null;
    return p;
  },
  z.object({
    institutionId: z.coerce.number().positive("Institution ID is required"),
    branchName: z.string().min(2, "Branch name must be at least 2 characters"),
    branchCode: z
      .string()
      .min(2, "Branch code must be at least 2 characters")
      .regex(/^[A-Z0-9_-]+$/i, "Branch code must contain only letters, numbers, underscores and hyphens"),
    division: z.string().min(1, "Division is required"),
    district: z.string().min(1, "District is required"),
    upazila: z.string().min(1, "Upazila is required"),
    postOffice: z.string().optional().nullable().or(z.literal("")),
    postalCode: z.string().optional().nullable().or(z.literal("")),
    address: z.string().optional().nullable().or(z.literal("")),
    phone: z.string().optional().nullable().or(z.literal("")),
    email: z.string().email("Invalid branch email").optional().nullable().or(z.literal("")),
    managerName: z.string().optional().nullable().or(z.literal("")),
    notes: z.string().optional().nullable().or(z.literal("")),
    status: z.enum(["active", "inactive"]).default("active"),
  })
);

const kycRequirementSchema = z.preprocess(
  (val) => {
    if (typeof val !== "object" || val === null) return val;
    const p = { ...val };
    if (p.requirementCode) p.requirementCode = String(p.requirementCode).trim().toUpperCase();
    if (!p.requirementCode && p.name) {
      p.requirementCode = String(p.name).toUpperCase().replace(/[^A-Z0-9]+/g, "_").slice(0, 50);
    }
    return p;
  },
  z.object({
    institutionId: z.coerce.number().positive("Institution ID is required"),
    applicableServiceId: z.coerce.number().optional().nullable(),
    name: z.string().min(2, "Requirement name is required"),
    requirementCode: z
      .string()
      .min(2, "Requirement code is required")
      .regex(/^[A-Z0-9_-]+$/i, "Requirement code must be alphanumeric"),
    requirementCategory: z
      .enum(["business_identity", "tax_regulatory", "financial_bank", "signatory_ownership", "operational_proof", "other"])
      .default("business_identity"),
    requirementType: z
      .enum(["document_upload", "text_input", "number_input", "boolean_check", "bank_account_verification"])
      .default("document_upload"),
    applicableBusinessTypes: z.any().optional().nullable(),
    documentType: z.string().optional().nullable().default("other"),
    description: z.string().optional().nullable().or(z.literal("")),
    instructions: z.string().optional().nullable().or(z.literal("")),
    allowedExtensions: z.string().optional().nullable().default("pdf,jpg,jpeg,png,webp"),
    maxFileSizeMb: z.coerce.number().min(1).max(50).default(5),
    maxFilesCount: z.coerce.number().min(1).max(10).default(1),
    documentSides: z.enum(["single", "both", "not_applicable"]).default("single"),
    isMandatory: z.coerce.boolean().default(true),
    requiresApproval: z.coerce.boolean().default(true),
    reviewInstructions: z.string().optional().nullable().or(z.literal("")),
    status: z.enum(["active", "inactive"]).default("active"),
    displayOrder: z.coerce.number().default(0),
  })
);


export const adminInstitutionsController = {
  async getDashboard(req, res, next) {
    try {
      const data = await adminInstitutionsService.getDashboard();
      res.json({
        success: true,
        data,
      });
    } catch (err) {
      next(err);
    }
  },

  async list(req, res, next) {
    try {
      const { search, type, status, page = 1, limit = 15 } = req.query;
      const data = await adminInstitutionsService.list({
        search,
        type,
        status,
        page: Number(page),
        limit: Number(limit),
      });

      res.json({
        success: true,
        count: data.institutions.length,
        data: data.institutions,
        institutions: data.institutions,
        pagination: data.pagination,
      });
    } catch (err) {
      next(err);
    }
  },

  async getById(req, res, next) {
    try {
      const id = Number(req.params.id);
      const data = await adminInstitutionsService.getById(id);
      res.json({
        success: true,
        data,
      });
    } catch (err) {
      next(err);
    }
  },

  async create(req, res, next) {
    try {
      const validated = institutionSchema.parse(req.body);
      const created = await adminInstitutionsService.create(validated, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(201).json({
        success: true,
        message: "Institution created successfully",
        data: created,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        const errorDetails = err.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ");
        return res.status(400).json({
          success: false,
          message: `Validation failed: ${errorDetails}`,
          errors: err.errors,
        });
      }
      next(err);
    }
  },

  async update(req, res, next) {
    try {
      const id = Number(req.params.id);
      const validated = institutionSchema.parse(req.body);

      const updated = await adminInstitutionsService.update(id, validated, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json({
        success: true,
        message: "Institution updated successfully",
        data: updated,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        const errorDetails = err.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ");
        return res.status(400).json({
          success: false,
          message: `Validation failed: ${errorDetails}`,
          errors: err.errors,
        });
      }
      next(err);
    }
  },

  async updateStatus(req, res, next) {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id) || id <= 0) {
        return res.status(400).json({ success: false, message: "Invalid institution ID" });
      }

      let status = req.body?.status;
      if (!status && typeof req.body === "string") {
        try {
          const parsed = JSON.parse(req.body);
          status = parsed?.status || parsed;
        } catch (_) {
          status = req.body;
        }
      }

      if (!status) {
        return res.status(400).json({ success: false, message: "Status is required in request body" });
      }

      const validStatuses = ["active", "draft", "inactive", "suspended"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: `Invalid institution status: '${status}'. Allowed values are: ${validStatuses.join(", ")}`,
        });
      }

      const updated = await adminInstitutionsService.updateStatus(id, status, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json({
        success: true,
        message: `Institution status updated to ${status}`,
        data: updated,
      });
    } catch (err) {
      next(err);
    }
  },

  async delete(req, res, next) {
    try {
      const id = Number(req.params.id);
      const result = await adminInstitutionsService.delete(id, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  async uploadLogo(req, res, next) {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "No image file uploaded or file format not supported.",
        });
      }
      const result = await adminInstitutionsService.uploadLogo(req.file);
      res.json({
        success: true,
        message: "Logo uploaded successfully",
        data: {
          url: result.url,
          logoUrl: result.url,
          filename: result.filename,
        },
        url: result.url,
        logoUrl: result.url,
        filename: result.filename,
      });
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     SERVICES HANDLERS
     ======================================================================== */

  async listServices(req, res, next) {
    try {
      const { institutionId, status, search, page = 1, limit = 20 } = req.query;
      const validInstId =
        institutionId && institutionId !== "all" && !isNaN(Number(institutionId)) && Number(institutionId) > 0
          ? Math.floor(Number(institutionId))
          : null;

      const data = await adminInstitutionsService.listServices({
        institutionId: validInstId,
        status,
        search,
        page: Number(page),
        limit: Number(limit),
      });

      res.json({
        success: true,
        data: data.services,
        services: data.services,
        pagination: data.pagination,
      });
    } catch (err) {
      next(err);
    }
  },

  async associateService(req, res, next) {
    try {
      const gatewayId = Number(req.params.gatewayId);
      const { institutionId } = req.body;
      if (!institutionId) {
        return res.status(400).json({ success: false, message: "institutionId is required" });
      }

      const result = await adminInstitutionsService.associateService(
        gatewayId,
        Number(institutionId),
        req.user,
        { ip: req.ip, userAgent: req.get("user-agent") }
      );

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  async disassociateService(req, res, next) {
    try {
      const gatewayId = Number(req.params.gatewayId);
      const result = await adminInstitutionsService.disassociateService(gatewayId, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     STAFF HANDLERS
     ======================================================================== */

  async listStaff(req, res, next) {
    try {
      const { institutionId, status, search, page = 1, limit = 20 } = req.query;
      const validInstId =
        institutionId && institutionId !== "all" && !isNaN(Number(institutionId)) && Number(institutionId) > 0
          ? Math.floor(Number(institutionId))
          : null;

      const data = await adminInstitutionsService.listStaff({
        institutionId: validInstId,
        status,
        search,
        page: Number(page),
        limit: Number(limit),
      });

      res.json({
        success: true,
        data: data.staff,
        staff: data.staff,
        pagination: data.pagination,
      });
    } catch (err) {
      next(err);
    }
  },

  async provisionStaff(req, res, next) {
    try {
      const validated = staffSchema.parse(req.body);
      const result = await adminInstitutionsService.provisionStaff(validated, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(201).json({
        success: true,
        message: "Institution staff provisioned successfully",
        data: result,
      });
    } catch (err) {
      next(err);
    }
  },

  async updateStaff(req, res, next) {
    try {
      const membershipId = Number(req.params.membershipId);
      const { roleName, membershipStatus } = req.body;
      const result = await adminInstitutionsService.updateStaffMembership(
        membershipId,
        { roleName, membershipStatus },
        req.user,
        { ip: req.ip, userAgent: req.get("user-agent") }
      );

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     KYC REQUIREMENTS HANDLERS
     ======================================================================== */

  async listKycRequirements(req, res, next) {
    try {
      const { institutionId, status } = req.query;
      const validInstId =
        institutionId && institutionId !== "all" && !isNaN(Number(institutionId)) && Number(institutionId) > 0
          ? Math.floor(Number(institutionId))
          : null;

      const data = await adminInstitutionsService.listKycRequirements({
        institutionId: validInstId,
        status,
      });

      res.json({
        success: true,
        data,
      });
    } catch (err) {
      next(err);
    }
  },

  async createKycRequirement(req, res, next) {
    try {
      const validated = kycRequirementSchema.parse(req.body);
      const created = await adminInstitutionsService.createKycRequirement(validated, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(201).json({
        success: true,
        message: "KYC requirement configured successfully",
        data: created,
      });
    } catch (err) {
      next(err);
    }
  },

  async updateKycRequirement(req, res, next) {
    try {
      const id = Number(req.params.id);
      const partial = kycRequirementSchema.partial().parse(req.body);
      await adminInstitutionsService.updateKycRequirement(id, partial, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json({
        success: true,
        message: "KYC requirement updated successfully",
      });
    } catch (err) {
      next(err);
    }
  },

  async deleteKycRequirement(req, res, next) {
    try {
      const id = Number(req.params.id);
      const result = await adminInstitutionsService.deleteKycRequirement(id, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     SETTINGS HANDLERS
     ======================================================================== */

  async getSettings(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const data = await adminInstitutionsService.getSettings(institutionId);
      res.json({
        success: true,
        data,
      });
    } catch (err) {
      next(err);
    }
  },

  async saveSettings(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const settingsPayload = req.body;
      const result = await adminInstitutionsService.saveSettings(
        institutionId,
        settingsPayload,
        req.user,
        { ip: req.ip, userAgent: req.get("user-agent") }
      );

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     BRANCHES & LOCATIONS HANDLERS
     ======================================================================== */

  async getBranchStats(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const data = await adminInstitutionsService.getBranchStats(institutionId);
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },

  async listBranches(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const { division, district, upazila, status, search, page = 1, limit = 15 } = req.query;
      const data = await adminInstitutionsService.listBranches(institutionId, {
        division,
        district,
        upazila,
        status,
        search,
        page: Number(page),
        limit: Number(limit),
      });

      res.json({
        success: true,
        data: data.branches,
        branches: data.branches,
        pagination: data.pagination,
      });
    } catch (err) {
      next(err);
    }
  },

  async getBranchById(req, res, next) {
    try {
      const branchId = Number(req.params.branchId);
      const branch = await adminInstitutionsService.getBranchById(branchId);
      res.json({ success: true, data: branch });
    } catch (err) {
      next(err);
    }
  },

  async createBranch(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const payload = { ...req.body, institutionId };
      const validated = branchSchema.parse(payload);

      const created = await adminInstitutionsService.createBranch(validated, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(201).json({
        success: true,
        message: "Branch created successfully",
        data: created,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        const errorDetails = err.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ");
        return res.status(400).json({
          success: false,
          message: `Validation failed: ${errorDetails}`,
          errors: err.errors,
        });
      }
      next(err);
    }
  },

  async updateBranch(req, res, next) {
    try {
      const branchId = Number(req.params.branchId);
      const partial = branchSchema.partial().parse(req.body);

      const updated = await adminInstitutionsService.updateBranch(branchId, partial, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json({
        success: true,
        message: "Branch updated successfully",
        data: updated,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        const errorDetails = err.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ");
        return res.status(400).json({
          success: false,
          message: `Validation failed: ${errorDetails}`,
          errors: err.errors,
        });
      }
      next(err);
    }
  },

  async updateBranchStatus(req, res, next) {
    try {
      const branchId = Number(req.params.branchId);
      const { status } = req.body;
      if (!["active", "inactive"].includes(status)) {
        return res.status(400).json({ success: false, message: "Status must be active or inactive" });
      }

      const result = await adminInstitutionsService.updateBranchStatus(branchId, status, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  async deleteBranch(req, res, next) {
    try {
      const branchId = Number(req.params.branchId);
      const result = await adminInstitutionsService.deleteBranch(branchId, req.user, {
        ip: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },

  async exportBranchesCsv(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const csvData = await adminInstitutionsService.exportBranchesCsv(institutionId);

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename=institution_${institutionId}_branches.csv`);
      res.status(200).send(csvData);
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     BANGLADESH GEOGRAPHIC MASTER DATA HANDLERS
     ======================================================================== */

  async getGeoDivisions(req, res, next) {
    try {
      const data = await adminInstitutionsService.getGeoDivisions();
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },

  async getGeoDistricts(req, res, next) {
    try {
      const { divisionId, division } = req.query;
      const data = await adminInstitutionsService.getGeoDistricts(divisionId || division || null);
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },

  async getGeoUpazilas(req, res, next) {
    try {
      const { districtId, district } = req.query;
      const data = await adminInstitutionsService.getGeoUpazilas(districtId || district || null);
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },

  /* ========================================================================
     INSTITUTION APPLICATIONS HANDLERS
     ======================================================================== */

  async listInstitutionApplications(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const { status, search, page = 1, limit = 15 } = req.query;
      const data = await adminInstitutionsService.listInstitutionApplications(institutionId, {
        status,
        search,
        page: Number(page),
        limit: Number(limit),
      });

      res.json({
        success: true,
        data: data.applications,
        applications: data.applications,
        pagination: data.pagination,
      });
    } catch (err) {
      next(err);
    }
  },

  async getInstitutionApplicationStats(req, res, next) {
    try {
      const institutionId = Number(req.params.institutionId);
      const data = await adminInstitutionsService.getInstitutionApplicationStats(institutionId);
      res.json({ success: true, data });
    } catch (err) {
      next(err);
    }
  },
};


