import { db } from "../../../config/db.js";

export const adminGatewaysRepository = {
  async getGatewayStats() {
    const [counts] = await db.execute(`
      SELECT 
        COUNT(*) AS totalGateways,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS activeGateways,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) AS inactiveGateways,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draftGateways
      FROM gateways
    `);

    const [appCounts] = await db.execute(`
      SELECT 
        COUNT(*) AS totalApplications,
        SUM(CASE WHEN status = 'applied' OR status = 'under_review' THEN 1 ELSE 0 END) AS pendingApplications,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approvedApplications,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejectedApplications
      FROM merchant_gateway_applications
    `);

    const [serviceCounts] = await db.execute(`
      SELECT 
        COUNT(*) AS totalServices,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS activeServices,
        SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspendedServices
      FROM merchant_gateway_services
    `);

    const g = counts[0] || {};
    const a = appCounts[0] || {};
    const s = serviceCounts[0] || {};

    return {
      totalGateways: Number(g.totalGateways || 0),
      activeGateways: Number(g.activeGateways || 0),
      inactiveGateways: Number(g.inactiveGateways || 0),
      draftGateways: Number(g.draftGateways || 0),
      publishedGateways: Number(g.activeGateways || 0),
      gatewayApplications: Number(a.totalApplications || 0),
      pendingApplications: Number(a.pendingApplications || 0),
      approvedApplications: Number(a.approvedApplications || 0),
      rejectedApplications: Number(a.rejectedApplications || 0),
      provisionedServices: Number(s.activeServices || 0),
      totalServices: Number(s.totalServices || 0),
    };
  },

  async listGateways({ search = "", status = "" } = {}) {
    const conditions = [];
    const params = [];

    if (search) {
      conditions.push("(name LIKE ? OR code LIKE ? OR description LIKE ? OR service_type LIKE ?)");
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }

    if (status && status !== "all") {
      conditions.push("status = ?");
      params.push(status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const [rows] = await db.execute(
      `SELECT * FROM gateways ${whereClause} ORDER BY created_at DESC`,
      params
    );

    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      code: r.code,
      logoUrl: r.logo_url,
      description: r.description,
      supportedMethods: typeof r.supported_methods === "string" ? JSON.parse(r.supported_methods) : (r.supported_methods || []),
      serviceType: r.service_type,
      qrSupported: Boolean(r.qr_supported),
      cardSupported: Boolean(r.card_supported),
      mobileSupported: Boolean(r.mobile_supported),
      apiSupported: Boolean(r.api_supported),
      requiredDocuments: typeof r.required_documents === "string" ? JSON.parse(r.required_documents) : (r.required_documents || []),
      serviceFee: Number(r.service_fee),
      setupFee: Number(r.setup_fee),
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  },

  async getGatewayById(id) {
    const [rows] = await db.execute("SELECT * FROM gateways WHERE id = ? LIMIT 1", [id]);
    if (!rows.length) return null;
    const r = rows[0];
    return {
      id: r.id,
      name: r.name,
      code: r.code,
      logoUrl: r.logo_url,
      description: r.description,
      supportedMethods: typeof r.supported_methods === "string" ? JSON.parse(r.supported_methods) : (r.supported_methods || []),
      serviceType: r.service_type,
      qrSupported: Boolean(r.qr_supported),
      cardSupported: Boolean(r.card_supported),
      mobileSupported: Boolean(r.mobile_supported),
      apiSupported: Boolean(r.api_supported),
      requiredDocuments: typeof r.required_documents === "string" ? JSON.parse(r.required_documents) : (r.required_documents || []),
      serviceFee: Number(r.service_fee),
      setupFee: Number(r.setup_fee),
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  },

  async createGateway(data) {
    const [res] = await db.execute(
      `INSERT INTO gateways (name, code, logo_url, description, supported_methods, service_type, qr_supported, card_supported, mobile_supported, api_supported, required_documents, service_fee, setup_fee, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.name,
        data.code,
        data.logoUrl || null,
        data.description || null,
        JSON.stringify(data.supportedMethods || []),
        data.serviceType || "Payment Gateway",
        data.qrSupported ? 1 : 0,
        data.cardSupported ? 1 : 0,
        data.mobileSupported ? 1 : 0,
        data.apiSupported ? 1 : 0,
        JSON.stringify(data.requiredDocuments || []),
        data.serviceFee || 1.5,
        data.setupFee || 0,
        data.status || "active",
      ]
    );
    return res.insertId;
  },

  async updateGateway(id, data) {
    await db.execute(
      `UPDATE gateways SET
        name = ?, code = ?, logo_url = ?, description = ?, supported_methods = ?,
        service_type = ?, qr_supported = ?, card_supported = ?, mobile_supported = ?,
        api_supported = ?, required_documents = ?, service_fee = ?, setup_fee = ?, status = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        data.name,
        data.code,
        data.logoUrl || null,
        data.description || null,
        JSON.stringify(data.supportedMethods || []),
        data.serviceType || "Payment Gateway",
        data.qrSupported ? 1 : 0,
        data.cardSupported ? 1 : 0,
        data.mobileSupported ? 1 : 0,
        data.apiSupported ? 1 : 0,
        JSON.stringify(data.requiredDocuments || []),
        data.serviceFee || 1.5,
        data.setupFee || 0,
        data.status || "active",
        id,
      ]
    );
  },

  async deleteGateway(id) {
    // Check if gateway is in use by applications or active services
    const [appCheck] = await db.execute(
      "SELECT id FROM merchant_gateway_applications WHERE gateway_id = ? LIMIT 1",
      [id]
    );
    const [svcCheck] = await db.execute(
      "SELECT id FROM merchant_gateway_services WHERE gateway_id = ? LIMIT 1",
      [id]
    );

    if (appCheck.length > 0 || svcCheck.length > 0) {
      // Soft-deactivate to maintain audit integrity
      await db.execute("UPDATE gateways SET status = 'inactive', updated_at = NOW() WHERE id = ?", [id]);
      return { softDeleted: true, message: "Gateway has associated applications or merchant services, so its status was set to Inactive." };
    }

    await db.execute("DELETE FROM gateways WHERE id = ?", [id]);
    return { softDeleted: false, message: "Gateway deleted successfully." };
  },

  async listApplications({ search = "", status = "" } = {}) {
    const conditions = [];
    const params = [];

    if (search) {
      conditions.push("(m.merchant_code LIKE ? OR p.company_name LIKE ? OR g.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)");
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
    }

    if (status && status !== "all") {
      if (status === "pending") {
        conditions.push("(mga.status = 'applied' OR mga.status = 'under_review')");
      } else {
        conditions.push("mga.status = ?");
        params.push(status);
      }
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const [rows] = await db.execute(
      `
        SELECT mga.*, m.merchant_code, m.user_id, COALESCE(p.company_name, m.merchant_code) AS company_name, 
               COALESCE(c.email, u.email) AS email, COALESCE(c.phone, u.phone) AS phone, COALESCE(c.name, p.company_name, u.email) AS full_name,
               g.name AS gateway_name, g.code AS gateway_code, g.logo_url, g.service_fee, g.service_type
        FROM merchant_gateway_applications mga
        JOIN merchants m ON mga.merchant_id = m.id
        JOIN users u ON m.user_id = u.id
        JOIN gateways g ON mga.gateway_id = g.id
        LEFT JOIN merchant_profiles p ON p.merchant_id = m.id
        LEFT JOIN merchant_contacts c ON c.merchant_id = m.id
        ${whereClause}
        ORDER BY mga.applied_at DESC
      `,
      params
    );

    return rows.map((r) => ({
      id: r.id,
      applicationReference: `BQR-APP-${String(r.id).padStart(6, "0")}`,
      merchantId: r.merchant_id,
      userId: r.user_id,
      gatewayId: r.gateway_id,
      merchantCode: r.merchant_code,
      companyName: r.company_name,
      contactName: r.full_name,
      email: r.email,
      phone: r.phone,
      gatewayName: r.gateway_name,
      gatewayCode: r.gateway_code,
      logoUrl: r.logo_url,
      serviceType: r.service_type,
      serviceFee: Number(r.service_fee),
      status: r.status,
      reviewNote: r.review_note,
      appliedAt: r.applied_at,
      reviewedAt: r.reviewed_at,
      updatedAt: r.updated_at,
    }));
  },

  async listServices({ search = "", status = "" } = {}) {
    const conditions = [];
    const params = [];

    if (search) {
      conditions.push("(m.merchant_code LIKE ? OR p.company_name LIKE ? OR g.name LIKE ? OR u.email LIKE ?)");
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }

    if (status && status !== "all") {
      conditions.push("mgs.status = ?");
      params.push(status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const [rows] = await db.execute(
      `
        SELECT mgs.*, m.merchant_code, m.user_id, COALESCE(p.company_name, m.merchant_code) AS company_name, 
               COALESCE(c.email, u.email) AS email, COALESCE(c.phone, u.phone) AS phone, COALESCE(c.name, p.company_name, u.email) AS full_name,
               g.name AS gateway_name, g.code AS gateway_code, g.logo_url, g.service_fee,
               g.qr_supported, g.card_supported, g.mobile_supported, g.api_supported
        FROM merchant_gateway_services mgs
        JOIN merchants m ON mgs.merchant_id = m.id
        JOIN users u ON m.user_id = u.id
        JOIN gateways g ON mgs.gateway_id = g.id
        LEFT JOIN merchant_profiles p ON p.merchant_id = m.id
        LEFT JOIN merchant_contacts c ON c.merchant_id = m.id
        ${whereClause}
        ORDER BY mgs.created_at DESC
      `,
      params
    );

    return rows.map((r) => {
      const rawConfig = typeof r.configuration === "string" ? JSON.parse(r.configuration) : (r.configuration || {});
      const maskedConfig = { ...rawConfig };
      if (maskedConfig.secret_key) maskedConfig.secret_key = "••••••••" + String(maskedConfig.secret_key).slice(-4);
      if (maskedConfig.apiKey) maskedConfig.apiKey = "••••••••" + String(maskedConfig.apiKey).slice(-4);
      if (maskedConfig.secretKey) maskedConfig.secretKey = "••••••••" + String(maskedConfig.secretKey).slice(-4);

      return {
        id: r.id,
        merchantId: r.merchant_id,
        userId: r.user_id,
        gatewayId: r.gateway_id,
        merchantCode: r.merchant_code,
        companyName: r.company_name,
        contactName: r.full_name,
        email: r.email,
        phone: r.phone,
        gatewayName: r.gateway_name,
        gatewayCode: r.gateway_code,
        logoUrl: r.logo_url,
        serviceType: r.service_type,
        serviceFee: Number(r.service_fee),
        status: r.status,
        configuration: maskedConfig,
        rawConfiguration: rawConfig,
        qrSupported: Boolean(r.qr_supported),
        cardSupported: Boolean(r.card_supported),
        mobileSupported: Boolean(r.mobile_supported),
        apiSupported: Boolean(r.api_supported),
        activatedAt: r.activated_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      };
    });
  },

  async getApplicationById(id) {
    const [rows] = await db.execute(
      `
        SELECT mga.*, m.merchant_code, m.user_id, COALESCE(p.company_name, m.merchant_code) AS company_name, 
               COALESCE(c.email, u.email) AS email, COALESCE(c.phone, u.phone) AS phone, COALESCE(c.name, p.company_name, u.email) AS full_name,
               g.name AS gateway_name, g.code AS gateway_code, g.logo_url, g.service_fee, g.service_type, 
               g.supported_methods, g.required_documents, g.description
        FROM merchant_gateway_applications mga
        JOIN merchants m ON mga.merchant_id = m.id
        JOIN users u ON m.user_id = u.id
        JOIN gateways g ON mga.gateway_id = g.id
        LEFT JOIN merchant_profiles p ON p.merchant_id = m.id
        LEFT JOIN merchant_contacts c ON c.merchant_id = m.id
        WHERE mga.id = ?
        LIMIT 1
      `,
      [id]
    );

    if (!rows.length) return null;
    const r = rows[0];

    return {
      id: r.id,
      applicationReference: `BQR-APP-${String(r.id).padStart(6, "0")}`,
      merchantId: r.merchant_id,
      userId: r.user_id,
      gatewayId: r.gateway_id,
      merchantCode: r.merchant_code,
      companyName: r.company_name,
      contactName: r.full_name,
      email: r.email,
      phone: r.phone,
      gatewayName: r.gateway_name,
      gatewayCode: r.gateway_code,
      logoUrl: r.logo_url,
      description: r.description,
      serviceType: r.service_type,
      serviceFee: Number(r.service_fee),
      supportedMethods: typeof r.supported_methods === "string" ? JSON.parse(r.supported_methods) : (r.supported_methods || []),
      requiredDocuments: typeof r.required_documents === "string" ? JSON.parse(r.required_documents) : (r.required_documents || []),
      status: r.status,
      reviewNote: r.review_note,
      appliedAt: r.applied_at,
      reviewedAt: r.reviewed_at,
      updatedAt: r.updated_at,
    };
  },

  async updateApplicationStatus(id, status, reviewNote) {
    await db.execute(
      `UPDATE merchant_gateway_applications SET status = ?, review_note = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?`,
      [status, reviewNote || null, id]
    );
  },

  async provisionGatewayService(merchantId, gatewayId, serviceType = "BanglaQR Interoperable", initialConfig = null) {
    const [existing] = await db.execute(
      `SELECT id, configuration FROM merchant_gateway_services WHERE merchant_id = ? AND gateway_id = ? LIMIT 1`,
      [merchantId, gatewayId]
    );

    const defaultConfig = initialConfig || {
      storeId: `STORE_${merchantId}_${gatewayId}`,
      merchantId: `MID_${merchantId}`,
      sandboxMode: true,
      apiKey: "",
      secretKey: "",
      webhookUrl: "",
      callbackUrl: "",
      updatedAt: new Date().toISOString(),
    };

    if (existing.length > 0) {
      await db.execute(
        `UPDATE merchant_gateway_services 
         SET status = 'active', activated_at = NOW(), updated_at = NOW() 
         WHERE id = ?`,
        [existing[0].id]
      );
      return existing[0].id;
    }

    const [res] = await db.execute(
      `INSERT INTO merchant_gateway_services (merchant_id, gateway_id, service_type, configuration, status, activated_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'active', NOW(), NOW(), NOW())`,
      [merchantId, gatewayId, serviceType, JSON.stringify(defaultConfig)]
    );
    return res.insertId;
  },

  async updateServiceStatus(id, status) {
    await db.execute(
      `UPDATE merchant_gateway_services SET status = ?, updated_at = NOW() WHERE id = ?`,
      [status, id]
    );
  },
};
